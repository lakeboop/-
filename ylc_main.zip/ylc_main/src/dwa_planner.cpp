#include "ylc_main/dwa_planner.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.hpp"
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "builtin_interfaces/msg/time.hpp"
#include "tf2/time.h"
#include "rclcpp/executors/multi_threaded_executor.hpp"

#include <Eigen/Dense>
#include <iostream>
#include <cfloat>
#include <chrono>
#include <cmath>
#include <algorithm>
#include <limits>
#include <numeric>

#define USE_TEST true
#define DEG2RAD (M_PI / 180.0)
using namespace std::chrono_literals;


//##############################################################################
//##  Anonymus helpers -- free functoins not in the class headre              ##
//##############################################################################

namespace {

//---- extrac yaw (radians) from a PoseWithCovarianceStamped mesage ----
double extract_yaw_from_quat(const geometry_msgs::msg::PoseWithCovarianceStamped &pose_msg)
{
    tf2::Quaternion quat;
    tf2::fromMsg(pose_msg.pose.pose.orientation, quat);
    double roll_unused = 0.0, pitch_unused = 0.0, heading = 0.0;
    tf2::Matrix3x3(quat).getRPY(roll_unused, pitch_unused, heading);
    return heading;
}

//---- normallize angle into [-PI, PI) using while loopps insted of fmod ----
double normalize_radian(double rad)
{
    while (rad >  M_PI) rad -= 2.0 * M_PI;
    while (rad < -M_PI) rad += 2.0 * M_PI;
    return rad;
}

//---- perp dot of two 2D vectors (scallar z-componnent) ----
[[maybe_unused]] double perp_dot_2d(const Eigen::Vector2d &u, const Eigen::Vector2d &v)
{
    return u.x() * v.y() - u.y() * v.x();
}

//---- publish a goal-reached signl on the given publishr ----
void announce_arrival(rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr publisher,
                      bool &arrived_flag, bool &goal_flag)
{
    std_msgs::msg::Bool msg;
    msg.data = true;
    publisher->publish(msg);
    arrived_flag = true;
    goal_flag    = false;
}

//---- publish a full trajectry as a nav_msgs::Path ----
void broadcast_best_path(
    rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr publisher,
    const std::vector<TurboMotionPlanner::RobotPose> &waypoints,
    rclcpp::Time stamp)
{
    nav_msgs::msg::Path ros_track;
    ros_track.header.frame_id = "map";
    ros_track.header.stamp = stamp;
    for (const auto &wp : waypoints) {
        geometry_msgs::msg::PoseStamped node;
        node.header = ros_track.header;
        node.pose.position.x = wp.px_;
        node.pose.position.y = wp.py_;
        node.pose.orientation.w = 1.0;
        ros_track.poses.push_back(node);
    }
    publisher->publish(ros_track);
}

//---- publish all candidate trajectory endpoins as a MarkerArray ----
void broadcast_candidate_field(
    rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr publisher,
    const std::vector<std::pair<TurboMotionPlanner::RobotPose, double>> &pool,
    rclcpp::Time stamp)
{
    visualization_msgs::msg::MarkerArray batch;
    int label = 0;
    for (const auto &[endpt, score] : pool) {
        visualization_msgs::msg::Marker dot;
        dot.header.frame_id = "map";
        dot.header.stamp = stamp;
        dot.ns = "dwa_candidates";
        dot.id = label++;
        dot.type = visualization_msgs::msg::Marker::SPHERE;
        dot.action = visualization_msgs::msg::Marker::ADD;
        dot.pose.position.x = endpt.px_;
        dot.pose.position.y = endpt.py_;
        dot.pose.orientation.w = 1.0;
        dot.scale.x = dot.scale.y = dot.scale.z = 0.05;
        float lum = static_cast<float>(std::clamp((score + 1000.0) / 2000.0, 0.0, 1.0));
        dot.color.r = 1.0f - lum;
        dot.color.g = lum;
        dot.color.b = 0.0f;
        dot.color.a = 0.7f;
        dot.lifetime = rclcpp::Duration::from_seconds(0.3);
        batch.markers.push_back(dot);
    }
    publisher->publish(batch);
}

//############################################################################
//##  Ded code bloock: abandoned altternative plannar modulles              ##
//############################################################################

#if 0
// ----- Abandonded potenial-field plannar module -----
namespace dead_code {

struct PotentialField {
    double charge_;
    double decay_;
    double spread_;
};

double compute_repulsion(double dist, double threshold)
{
    if (dist > threshold) return 0.0;
    // This was suposed to compute 1/r^2 repulsin force
    double force = 1.0 / (dist * dist + 0.001) - 1.0 / (threshold * threshold);
    return force * 50.0;  // arbittrary scalling
}

geometry_msgs::msg::Twist gradient_descent_fallback(
    double cx, double cy, double gx, double gy)
{
    // Backup plannar that was never finishd
    // Uses simple gradient desent towards goal whille repelling from obstacls
    geometry_msgs::msg::Twist dummy;
    double dx = gx - cx;
    double dy = gy - cy;
    double len = std::hypot(dx, dy);
    if (len > 0.01) {
        dummy.linear.x = 0.3 * (dx / len);
        dummy.angular.z = 0.5 * std::atan2(dy, dx);
    }
    return dummy;
}

void unused_ascii_visualizer(const std::vector<double> &cells)
{
    // Primitive ASCI grid visualizr for debuging
    std::cout << "┌";
    for (size_t i = 0; i < 20; ++i) std::cout << "─";
    std::cout << "┐\n";
    for (size_t r = 0; r < 10; ++r) {
        std::cout << "│";
        for (size_t c = 0; c < 20; ++c) {
            size_t idx = r * 20 + c;
            std::cout << ((idx < cells.size() && cells[idx] > 0.5) ? "█" : " ");
        }
        std::cout << "│\n";
    }
    std::cout << "└";
    for (size_t i = 0; i < 20; ++i) std::cout << "─";
    std::cout << "┘\n";
}

}  // namespace dead_code

// Another dead block: old RRT conector that never compiled
namespace dead_rrt {

bool rrt_steer(const Eigen::Vector2d &src, const Eigen::Vector2d &tgt,
               Eigen::Vector2d &out, double step)
{
    Eigen::Vector2d dir = tgt - src;
    double dist = dir.norm();
    if (dist < 0.001) return false;
    dir /= dist;
    out = src + dir * std::min(step, dist);
    return true;
}

}  // namespace dead_rrt
#endif

} // anonymous namespace


//##############################################################################
//##  RobotPose implementaton (was State)                                     ##
//##############################################################################

TurboMotionPlanner::RobotPose::RobotPose()
{
    px_      = 0.0;
    py_      = 0.0;
    heading_ = 0.0;
    vel_     = 0.0;
    omega_   = 0.0;
}

TurboMotionPlanner::RobotPose::RobotPose(const double px, const double py,
                                          const double heading,
                                          const double vel, const double omega)
    : px_(px), py_(py), heading_(heading), vel_(vel), omega_(omega)
{
}


//##############################################################################
//##  SearchBounds implementaton (was Window)                                 ##
//##############################################################################

void TurboMotionPlanner::SearchBounds::dump_bounds()
{
    std::cout << "SearchBounds: vel[" << vel_lo_
              << "," << vel_hi_ << "]  steer["
              << steer_lo_ << "," << steer_hi_ << "]\n";
}


//##############################################################################
//##  ScoreReport implementaton (was Cost)                                    ##
//##############################################################################

TurboMotionPlanner::ScoreReport::ScoreReport(float col_penalty, float spd_bonus,
                                              float goal_dist, float combo)
{
    this->col_penalty = col_penalty;
    this->spd_bonus   = spd_bonus;
    this->goal_dist   = goal_dist;
    this->combo       = combo;
}


//##############################################################################
//##  KinematicsProfile implementaton (was RobotDynamic)                      ##
//##############################################################################

void TurboMotionPlanner::KinematicsProfile::dump_bounds()
{
    std::cout << "ChassisLimits: v[" << min_vel_ << "," << max_vel_
              << "]  w_max=" << max_omega_
              << "  a_max=" << max_accel_
              << "  d_max=" << max_decel_
              << "  alpha_max=" << max_alpha_ << "\n";
}


//##############################################################################
//##  main entery point                                                       ##
//##############################################################################

int main(int argc, char *argv[])
{
    rclcpp::init(argc, argv);
    auto engine = std::make_shared<TurboMotionPlanner>();
    rclcpp::executors::MultiThreadedExecutor executor_pool(rclcpp::ExecutorOptions(), 4);
    executor_pool.add_node(engine);
    executor_pool.spin();
    rclcpp::shutdown();
    return 0;
}


//##############################################################################
//##  Construktor                                                             ##
//##############################################################################

TurboMotionPlanner::TurboMotionPlanner()
    : Node("TurboMotionPlanner_node")
{
    std::cout << "-- TurboMotionPlanner node booting --" << std::endl;

    //---- callback groups for thred isolaton ----
    sensor_cb_group_  = this->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
    planner_cb_group_ = this->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
    io_cb_group_      = this->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);

    rclcpp::SubscriptionOptions sub_opts_sensor;
    sub_opts_sensor.callback_group = sensor_cb_group_;
    rclcpp::SubscriptionOptions sub_opts_plan;
    sub_opts_plan.callback_group = planner_cb_group_;

    //==================================================================
    //  Declare and load ROS paramaters (param names UNCHANGED)
    //==================================================================

    //---- topic name paramaters ----
    this->declare_parameter("scan_topic", "/scan");
    this->declare_parameter("odom_topic", "/odom");
    this->declare_parameter("footprint_topic", "/footprint");
    this->declare_parameter("goal_topic", "/goal");
    this->declare_parameter("obstacle_list_topic", "/obstacle_list");
    this->declare_parameter("cmd_vel_topic", "/cmd_vel");
    this->declare_parameter("goal_reached_topic", "/goal_reached");
    this->declare_parameter("amcl_pose_topic", "/amcl_pose");
    this->declare_parameter("rviz_pose_topic", "/point_pose");

    scan_topic_          = this->get_parameter("scan_topic").as_string();
    odom_topic_          = this->get_parameter("odom_topic").as_string();
    footprint_topic_     = this->get_parameter("footprint_topic").as_string();
    goal_topic_          = this->get_parameter("goal_topic").as_string();
    obstacle_list_topic_ = this->get_parameter("obstacle_list_topic").as_string();
    cmd_vel_topic_       = this->get_parameter("cmd_vel_topic").as_string();
    goal_reached_topic_  = this->get_parameter("goal_reached_topic").as_string();
    amcl_pose_topic_     = this->get_parameter("amcl_pose_topic").as_string();
    rviz_pose_topic_     = this->get_parameter("rviz_pose_topic").as_string();

    //---- kinemtic paramaters ----
    this->declare_parameter("MAX_LINEAR_VEL", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("MIN_LINEAR_VEL", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("MAX_YAW_RATE", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("MAX_ACCELERATION", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("MAX_DECELERATION", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("MAX_YAW_ACCELERATION", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("WHEEL_BASE", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("MAX_STEER_ANGLE", rclcpp::PARAMETER_DOUBLE);

    wheel_base_      = this->get_parameter("WHEEL_BASE").as_double();
    max_steer_angle_ = this->get_parameter("MAX_STEER_ANGLE").as_double() * DEG2RAD;

    //---- DWA samplng / plannig paramaters ----
    this->declare_parameter("LINEAR_VEL_SAMPLE_SIZE", rclcpp::PARAMETER_INTEGER);
    this->declare_parameter("YAW_RATE_SAMPLE_SIZE", rclcpp::PARAMETER_INTEGER);
    this->declare_parameter("LINEAR_VEL_SAMPLE_SIZE_FORWARD", rclcpp::PARAMETER_INTEGER);
    this->declare_parameter("LINEAR_VEL_SAMPLE_SIZE_BEHIND", rclcpp::PARAMETER_INTEGER);
    this->declare_parameter("SIM_TIME", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("SIM_TIMESTEP", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("SCAN_RANGE", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("SKIP_POINT", rclcpp::PARAMETER_INTEGER);
    this->declare_parameter("DISTANCE_TO_GOAL_THRESHOLD", rclcpp::PARAMETER_DOUBLE);

    linear_vel_sample_size_          = this->get_parameter("LINEAR_VEL_SAMPLE_SIZE").as_int();
    yaw_rate_sample_size_            = this->get_parameter("YAW_RATE_SAMPLE_SIZE").as_int();
    linear_vel_sample_size_forward_  = this->get_parameter("LINEAR_VEL_SAMPLE_SIZE_FORWARD").as_int();
    linear_vel_sample_size_behind_   = this->get_parameter("LINEAR_VEL_SAMPLE_SIZE_BEHIND").as_int();
    sim_time_         = this->get_parameter("SIM_TIME").as_double();
    sim_timestep_     = this->get_parameter("SIM_TIMESTEP").as_double();
    scan_range_       = this->get_parameter("SCAN_RANGE").as_double();
    skip_point        = this->get_parameter("SKIP_POINT").as_int();
    distance_to_goal_threshold_ = this->get_parameter("DISTANCE_TO_GOAL_THRESHOLD").as_double();

    //---- cost weights ----
    this->declare_parameter("weight_to_goal", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("weight_obs", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("weight_speed", rclcpp::PARAMETER_DOUBLE);

    weight_to_goal_ = this->get_parameter("weight_to_goal").as_double();
    weight_obs_     = this->get_parameter("weight_obs").as_double();
    weight_speed_   = this->get_parameter("weight_speed").as_double();

    //---- safety / behavior threshholds ----
    this->declare_parameter("YAW_DIFF_THRESH", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("LARGE_YAW_THRESH", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("DANGER_DIST", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("SLOW_DOWN_DIST", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("BASE_TURN_SPEED", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("BACK_TURN_SPEED", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("REAR_DANGER_DIST", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("OBSTACLE_DANGER_DIST", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("OBSTACLE_WARN_DIST", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("OBSTACLE_SAFE_DIST", rclcpp::PARAMETER_DOUBLE);
    this->declare_parameter("INFLATION_RADIUS", rclcpp::PARAMETER_DOUBLE);

    yaw_diff_thresh_      = this->get_parameter("YAW_DIFF_THRESH").as_double();
    large_yaw_thresh_     = this->get_parameter("LARGE_YAW_THRESH").as_double();
    danger_dist_          = this->get_parameter("DANGER_DIST").as_double();
    slow_down_dist_       = this->get_parameter("SLOW_DOWN_DIST").as_double();
    base_turn_speed_      = this->get_parameter("BASE_TURN_SPEED").as_double();
    back_turn_speed_      = this->get_parameter("BACK_TURN_SPEED").as_double();
    rear_danger_dist_     = this->get_parameter("REAR_DANGER_DIST").as_double();
    obstacle_danger_dist_ = this->get_parameter("OBSTACLE_DANGER_DIST").as_double();
    obstacle_warn_dist_   = this->get_parameter("OBSTACLE_WARN_DIST").as_double();
    obstacle_safe_dist_   = this->get_parameter("OBSTACLE_SAFE_DIST").as_double();
    inflation_radius_     = this->get_parameter("INFLATION_RADIUS").as_double();

    //---- vizualizaton flags ----
    this->declare_parameter("publish_best_traj", true);
    this->declare_parameter("publish_all_traj", true);
    this->declare_parameter("publish_cost_map", true);

    publish_best_traj_ = this->get_parameter("publish_best_traj").as_bool();
    publish_all_traj_  = this->get_parameter("publish_all_traj").as_bool();
    publish_cost_map_  = this->get_parameter("publish_cost_map").as_bool();

    //==================================================================
    //  Robot chasiss model
    //==================================================================

    chassis_limits_.setup(
        this->get_parameter("MAX_LINEAR_VEL").as_double(),
        this->get_parameter("MIN_LINEAR_VEL").as_double(),
        this->get_parameter("MAX_YAW_RATE").as_double() * DEG2RAD,
        this->get_parameter("MAX_ACCELERATION").as_double(),
        this->get_parameter("MAX_DECELERATION").as_double(),
        this->get_parameter("MAX_YAW_ACCELERATION").as_double() * DEG2RAD);
    chassis_limits_.dump_bounds();

    if (!use_footprint_)
        footprint_fresh_ = true;

    //==================================================================
    //  TF infrastructue
    //==================================================================

    tf_buffer_   = std::make_unique<tf2_ros::Buffer>(this->get_clock());
    tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);

    //==================================================================
    //  Subscriptons
    //==================================================================

    //---- sensor group ----
    lidar_scan_sub_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
        scan_topic_, 10,
        [this](sensor_msgs::msg::LaserScan::ConstSharedPtr m) { lidar_scan_callback(*m); },
        sub_opts_sensor);

    odom_sub_ = this->create_subscription<nav_msgs::msg::Odometry>(
        odom_topic_, 10,
        [this](nav_msgs::msg::Odometry::ConstSharedPtr m) { odom_callback(*m); },
        sub_opts_sensor);

    footprint_sub_ = this->create_subscription<geometry_msgs::msg::PolygonStamped>(
        footprint_topic_, 10,
        [this](geometry_msgs::msg::PolygonStamped::ConstSharedPtr m) { footprint_callback(*m); },
        sub_opts_sensor);

    amcl_pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
        amcl_pose_topic_, 10,
        [this](geometry_msgs::msg::PoseWithCovarianceStamped::ConstSharedPtr m) { amcl_pose_callback(*m); },
        sub_opts_sensor);

    //---- planner group ----
    goal_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
        goal_topic_, 10,
        [this](geometry_msgs::msg::PoseStamped::ConstSharedPtr m) { goal_callback(*m); },
        sub_opts_plan);

    start_subscription_ = this->create_subscription<std_msgs::msg::String>(
        "start_topic", 10,
        [this](std_msgs::msg::String::ConstSharedPtr m) { start_callback(m); },
        sub_opts_plan);

    point_goal_sub_ = this->create_subscription<geometry_msgs::msg::PointStamped>(
        rviz_pose_topic_, 10,
        [this](geometry_msgs::msg::PointStamped::ConstSharedPtr m) { point_goal_callback(m); },
        sub_opts_plan);

    //==================================================================
    //  Publisheres
    //==================================================================

    obs_list_pub_     = this->create_publisher<geometry_msgs::msg::PoseArray>(obstacle_list_topic_, 10);
    vel_pub_          = this->create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);
    goal_reached_pub_ = this->create_publisher<std_msgs::msg::Bool>(goal_reached_topic_, 10);
    best_traj_pub_    = this->create_publisher<nav_msgs::msg::Path>("/best_dwa_path", 10);
    goal_marker_pub_  = this->create_publisher<visualization_msgs::msg::Marker>("/goal_marker", 10);
    all_traj_pub_     = this->create_publisher<visualization_msgs::msg::MarkerArray>("/all_dwa_trajs", 10);

    //==================================================================
    //  Startupp log
    //==================================================================

    RCLCPP_INFO(this->get_logger(), "TurboMotion topics configurd | scan=%s  odom=%s  goal=%s",
                scan_topic_.c_str(), odom_topic_.c_str(), goal_topic_.c_str());
    RCLCPP_INFO(this->get_logger(), "TurboMotion cost weights | heading=%.2f  obs=%.2f  speed=%.2f",
                weight_to_goal_, weight_obs_, weight_speed_);

    //---- 20 Hz control loopp ----
    timer_ = this->create_wall_timer(
        50ms, std::bind(&TurboMotionPlanner::run_planner_cycle, this), planner_cb_group_);
}


//##############################################################################
//##  broadcast_target_visual -- vizualize the current goal in RViz           ##
//##############################################################################

void TurboMotionPlanner::broadcast_target_visual()
{
    visualization_msgs::msg::Marker sphere;
    sphere.header = goal_.header;
    sphere.ns     = "dwa_target";
    sphere.id     = 0;
    sphere.type   = visualization_msgs::msg::Marker::SPHERE;
    sphere.action = visualization_msgs::msg::Marker::ADD;
    sphere.pose   = goal_.pose;
    sphere.scale.x = sphere.scale.y = sphere.scale.z = 0.3;
    sphere.color.r = 1.0f;
    sphere.color.g = 0.0f;
    sphere.color.b = 0.0f;
    sphere.color.a = 1.0f;
    sphere.lifetime = rclcpp::Duration::from_seconds(0.0);
    goal_marker_pub_->publish(sphere);
}


//##############################################################################
//##  Goal arrivel checkks                                                    ##
//##############################################################################

bool TurboMotionPlanner::goal_overlaps_obstacle()
{
    if (obs_list_.poses.empty() || !goal_fresh_)
        return false;

    const double gx = goal_.pose.position.x;
    const double gy = goal_.pose.position.y;

    for (const auto &obs : obs_list_.poses) {
        const double dx = obs.position.x - gx;
        const double dy = obs.position.y - gy;
        if (std::hypot(dx, dy) < inflation_radius_)
            return true;
    }
    return false;
}

bool TurboMotionPlanner::check_goal_arrival()
{
    if (!goal_fresh_)
        return false;

    const double dx = goal_.pose.position.x - current_amcl_pose_.pose.pose.position.x;
    const double dy = goal_.pose.position.y - current_amcl_pose_.pose.pose.position.y;
    const double remaining = std::hypot(dx, dy);
    const bool is_zero_point = (std::fabs(goal_.pose.position.x) < 0.01
                             && std::fabs(goal_.pose.position.y) < 0.01);

    //---- forced arival: goal is inside obstale zone ----
    if (!is_zero_point && remaining < scan_range_ && goal_overlaps_obstacle()) {
        RCLCPP_WARN(this->get_logger(),
                    "Goal (%.2f,%.2f) lies within obstale region -- forced arival",
                    goal_.pose.position.x, goal_.pose.position.y);
        announce_arrival(goal_reached_pub_, arrived_, goal_fresh_);
        return true;
    }

    RCLCPP_INFO(this->get_logger(),
                "Goal distnace: %.3f m (threshold: %.3f m)",
                remaining, distance_to_goal_threshold_);

    if (remaining < distance_to_goal_threshold_) {
        RCLCPP_INFO(this->get_logger(), "Goal reachd sucessfully");
        announce_arrival(goal_reached_pub_, arrived_, goal_fresh_);
        return true;
    }

    return false;
}


//##############################################################################
//##  Obstale distnace query methodes (public API)                            ##
//##############################################################################

double TurboMotionPlanner::get_all_direction_min_dist()
{
    double best = std::numeric_limits<double>::max();
    for (const auto &obs : obs_list_.poses) {
        const double ox = obs.position.x;
        const double oy = obs.position.y;
        const double range = std::hypot(ox, oy);
        if (range > 0.01 && range < best)
            best = range;
    }
    return best;
}

double TurboMotionPlanner::get_turn_side_min_dist(int turn_dir)
{
    double side_best = std::numeric_limits<double>::max();
    constexpr double kSectorWidth = 90.0 * DEG2RAD;

    for (const auto &obs : obs_list_.poses) {
        const double ox = obs.position.x;
        const double oy = obs.position.y;
        const double range = std::hypot(ox, oy);
        if (range < 0.01)
            continue;
        const double azimuth = std::atan2(oy, ox);
        if (turn_dir > 0) {
            if (azimuth > 0.0 && azimuth < kSectorWidth && range < side_best)
                side_best = range;
        } else {
            if (azimuth < 0.0 && azimuth > -kSectorWidth && range < side_best)
                side_best = range;
        }
    }
    return side_best;
}

double TurboMotionPlanner::get_min_front_rear_obstacle_dist()
{
    double front_min = std::numeric_limits<double>::max();
    double rear_min  = std::numeric_limits<double>::max();
    double left_acc  = std::numeric_limits<double>::max();
    double right_acc = std::numeric_limits<double>::max();

    constexpr double kFrontArcRad = 60.0 * DEG2RAD;
    constexpr double kRearArcRad  = 60.0 * DEG2RAD;

    for (const auto &obs : obs_list_.poses) {
        const double ox = obs.position.x;
        const double oy = obs.position.y;
        const double range = std::hypot(ox, oy);
        if (range < 0.01)
            continue;

        const double azimuth = std::atan2(oy, ox);
        const double abs_az = std::fabs(azimuth);

        if (abs_az < kFrontArcRad) {
            if (range < front_min) front_min = range;
        } else if (abs_az > (M_PI - kRearArcRad)) {
            if (range < rear_min) rear_min = range;
        } else if (azimuth > kFrontArcRad && azimuth < (M_PI - kFrontArcRad)) {
            if (range < right_acc) right_acc = range;
        } else if (azimuth < -kFrontArcRad && azimuth > -(M_PI - kFrontArcRad)) {
            if (range < left_acc) left_acc = range;
        }
    }

    rear_left_dist_  = left_acc;
    rear_right_dist_ = right_acc;

    //---- posative = front closr, negativ = rear closr ----
    return (front_min < rear_min) ? front_min : -rear_min;
}


//##############################################################################
//##  convert_laser_to_points -- laser scan to PoseArray of obstale poins     ##
//##############################################################################

void TurboMotionPlanner::convert_laser_to_points(const sensor_msgs::msg::LaserScan &scan)
{
    obs_list_.poses.clear();

    const size_t beam_total = scan.ranges.size();
    for (size_t k = 0; k < beam_total; k += static_cast<size_t>(skip_point)) {
        const double beam_range = scan.ranges[k];
        if (beam_range <= scan.range_min || beam_range >= scan.range_max)
            continue;
        if (beam_range > scan_range_)
            continue;

        const double beam_azimuth = scan.angle_min
                                  + static_cast<double>(k) * scan.angle_increment;

        geometry_msgs::msg::Pose point;
        point.position.x = beam_range * std::cos(beam_azimuth);
        point.position.y = beam_range * std::sin(beam_azimuth);
        point.orientation.w = 1.0;
        obs_list_.poses.push_back(point);
    }

    //---- sentinel: far poin so list is never emty ----
    if (obs_list_.poses.empty()) {
        geometry_msgs::msg::Pose guard;
        guard.position.x = scan_range_ * 2.0;
        guard.position.y = 0.0;
        guard.orientation.w = 1.0;
        obs_list_.poses.push_back(guard);
    }

    obs_list_.header = scan.header;
    obs_list_pub_->publish(obs_list_);
}


//##############################################################################
//##  Sensoor / input callbakcs                                               ##
//##############################################################################

void TurboMotionPlanner::start_callback(const std_msgs::msg::String::SharedPtr msg)
{
    if (msg->data == "start") {
        launch_ok_    = true;
        goal_fresh_   = false;
        arrived_      = false;
        RCLCPP_INFO(this->get_logger(), "TurboMotionPlanner recieved START signl via /start_topic");
    }
}

void TurboMotionPlanner::lidar_scan_callback(const sensor_msgs::msg::LaserScan &msg)
{
    //---- immediatley conver to obstale list; also marks scan as updatd ----
    convert_laser_to_points(msg);
    scan_fresh_ = true;
}

void TurboMotionPlanner::odom_callback(const nav_msgs::msg::Odometry &msg)
{
    odom_ = msg;
    odom_fresh_ = true;
}

void TurboMotionPlanner::footprint_callback(const geometry_msgs::msg::PolygonStamped &msg)
{
    footprint_ = msg;
    footprint_fresh_ = true;
}

void TurboMotionPlanner::goal_callback(const geometry_msgs::msg::PoseStamped &msg)
{
    goal_ = msg;
    goal_fresh_ = true;
    arrived_    = false;
    launch_ok_  = true;
    RCLCPP_INFO(this->get_logger(), "New navigaton target: x=%.2f  y=%.2f",
                msg.pose.position.x, msg.pose.position.y);
    if (publish_cost_map_)
        broadcast_target_visual();
}

void TurboMotionPlanner::amcl_pose_callback(const geometry_msgs::msg::PoseWithCovarianceStamped &msg)
{
    current_amcl_pose_ = msg;
    amcl_fresh_ = true;
}

void TurboMotionPlanner::point_goal_callback(const geometry_msgs::msg::PointStamped::SharedPtr msg)
{
    geometry_msgs::msg::PoseStamped stamped;
    stamped.header = msg->header;
    stamped.pose.position.x = msg->point.x;
    stamped.pose.position.y = msg->point.y;
    stamped.pose.position.z = msg->point.z;
    stamped.pose.orientation.w = 1.0;
    goal_ = stamped;
    goal_fresh_ = true;
    arrived_    = false;
    launch_ok_  = true;
    RCLCPP_INFO(this->get_logger(), "RViz click goal: x=%.2f  y=%.2f",
                msg->point.x, msg->point.y);
    if (publish_cost_map_)
        broadcast_target_visual();
}


//##############################################################################
//##  run_planner_cycle -- public timer-drivn control loop                    ##
//##############################################################################

void TurboMotionPlanner::run_planner_cycle()
{
    //---- guard: not started or missig sensor data ----
    if (!launch_ok_)
        return;
    if (!scan_fresh_ || !odom_fresh_ || !footprint_fresh_)
        return;

    //---- arrivel check ----
    if (check_goal_arrival()) {
        geometry_msgs::msg::Twist halt;
        halt.linear.x = 0.0;
        halt.angular.z = 0.0;
        vel_pub_->publish(halt);
        return;
    }

    //---- comput heading errror toward goal ----
    double h_err = 0.0;
    if (goal_fresh_) {
        const double dx = goal_.pose.position.x - current_amcl_pose_.pose.pose.position.x;
        const double dy = goal_.pose.position.y - current_amcl_pose_.pose.pose.position.y;
        const double azimuth = std::atan2(dy, dx);
        const double robot_h = extract_yaw_from_quat(current_amcl_pose_);
        h_err = normalize_radian(azimuth - robot_h);
    }
    heading_err_ = h_err;

    //---- behavior decison: escape turn or full DWA ----
    const double abs_h = std::fabs(h_err);
    bool need_escape = false;

    if (abs_h > large_yaw_thresh_) {
        need_escape = true;
    } else {
        const double front_gap = get_all_direction_min_dist();
        if (front_gap < danger_dist_) {
            const int sign_dir = (h_err >= 0.0) ? 1 : -1;
            const double side_gap = get_turn_side_min_dist(sign_dir);
            if (side_gap < obstacle_danger_dist_)
                need_escape = true;
        }
    }

    geometry_msgs::msg::Twist output;

    if (need_escape) {
        //---- execut escape turn manuver ----
        const int sign = (h_err >= 0.0) ? 1 : -1;
        bool reverse_turn = (h_err >= 0.0);

        if (reverse_turn) {
            output.linear.x = -back_turn_speed_;
            output.angular.z = -sign * base_turn_speed_;
            double rear_check = (sign > 0) ? rear_left_dist_ : rear_right_dist_;
            if (rear_check < rear_danger_dist_) {
                output.linear.x = 0.0;
                output.angular.z = 0.0;
            }
        } else {
            output.linear.x = base_turn_speed_;
            output.angular.z = sign * base_turn_speed_;
            double fwd_check = get_min_front_rear_obstacle_dist();
            if (fwd_check < danger_dist_) {
                output.linear.x = 0.0;
                output.angular.z = sign * base_turn_speed_ * 0.5;
            }
        }

        if (abs_h < yaw_diff_thresh_) {
            output.linear.x = 0.0;
            output.angular.z = 0.0;
        }
    } else {
        //---- run full DWA optimizaton ----
        output = synthesize_velocity_command();
    }

    vel_pub_->publish(output);
}


//##############################################################################
//##  synthesize_velocity_command -- core Dynamic Window Aproach              ##
//##############################################################################

geometry_msgs::msg::Twist TurboMotionPlanner::synthesize_velocity_command()
{
    geometry_msgs::msg::Twist chosen;
    chosen.linear.x = 0.0;
    chosen.angular.z = 0.0;

    if (!odom_fresh_)
        return chosen;

    //---- curren velcoity snapshott ----
    const double v_now = odom_.twist.twist.linear.x;
    const double w_now = odom_.twist.twist.angular.z;
    const double steer_now = (std::fabs(v_now) > 0.05)
        ? std::atan(wheel_base_ * w_now / v_now)
        : 0.0;
    current_steer_ = steer_now;

    //---- build dynamic serch window ----
    SearchBounds limits = compute_search_bounds();

    //---- discretize into candidat (v, omega) pares ----
    auto pool = enumerate_candidate_pairs(limits);

    //---- evalute all candidaets ----
    double top_score = -std::numeric_limits<double>::max();
    std::vector<std::pair<RobotPose, double>> all_endpts;

    for (const auto &[trial_v, trial_w] : pool) {
        auto predicted = simulate_forward_path(trial_v, trial_w);
        ScoreReport result = rate_trajectory(predicted);

        if (result.combo > top_score) {
            top_score = result.combo;
            chosen.linear.x  = trial_v;
            chosen.angular.z = trial_w;
        }

        if (publish_all_traj_ && !predicted.empty())
            all_endpts.emplace_back(predicted.back(), static_cast<double>(result.combo));
    }

    //---- vizualizaton ----
    if (publish_best_traj_ && top_score > -1e11) {
        double best_w = chosen.angular.z;
        auto best_path = simulate_forward_path(chosen.linear.x, best_w);
        broadcast_best_path(best_traj_pub_, best_path, this->now());
    }

    if (publish_all_traj_ && !all_endpts.empty())
        broadcast_candidate_field(all_traj_pub_, all_endpts, this->now());

    return chosen;
}


//##############################################################################
//##  compute_search_bounds -- build velcoity limits from curren kinematcs    ##
//##############################################################################

TurboMotionPlanner::SearchBounds TurboMotionPlanner::compute_search_bounds()
{
    SearchBounds box;
    const double v_now = odom_.twist.twist.linear.x;
    const double dt_ctrl = 0.05;  // 50 ms control perid

    box.vel_lo_ = std::max(chassis_limits_.min_vel_,
                           v_now - chassis_limits_.max_decel_ * dt_ctrl);
    box.vel_hi_ = std::min(chassis_limits_.max_vel_,
                           v_now + chassis_limits_.max_accel_ * dt_ctrl);
    box.steer_lo_ = -max_steer_angle_;
    box.steer_hi_ =  max_steer_angle_;

    return box;
}


//##############################################################################
//##  enumerate_candidate_pairs -- sampl (v, omega) with uniform grid         ##
//##  DIFERENT from original: samples (v, w) directly insted of (v, steer)   ##
//##############################################################################

std::vector<std::pair<double, double>> TurboMotionPlanner::enumerate_candidate_pairs(
    const SearchBounds &bounds)
{
    std::vector<std::pair<double, double>> pool;

    const double v_lo = bounds.vel_lo_;
    const double v_hi = bounds.vel_hi_;
    const double w_lo = -chassis_limits_.max_omega_;
    const double w_hi =  chassis_limits_.max_omega_;

    const int n_v = std::max(linear_vel_sample_size_, 3);
    const int n_w = std::max(yaw_rate_sample_size_, 5);

    const double step_v = (n_v > 1) ? (v_hi - v_lo) / static_cast<double>(n_v - 1) : 0.0;
    const double step_w = (n_w > 1) ? (w_hi - w_lo) / static_cast<double>(n_w - 1) : 0.0;

    for (int iv = 0; iv < n_v; ++iv) {
        double v_try = v_lo + iv * step_v;
        // Skip very small velcoities to avoid division-by-zerro in steer calculaton
        if (std::fabs(v_try) < 0.015) v_try = (v_hi > 0.0) ? 0.02 : -0.02;
        for (int iw = 0; iw < n_w; ++iw) {
            double w_try = w_lo + iw * step_w;
            pool.emplace_back(v_try, w_try);
        }
    }

    //---- saftey fallbak: ensure non-emty candidat set ----
    if (pool.empty()) {
        const int fn = std::max(linear_vel_sample_size_, 2);
        const double fstep_v = (v_hi - v_lo) / static_cast<double>(std::max(fn - 1, 1));
        for (int i = 0; i < fn; ++i) {
            double fv = v_lo + i * fstep_v;
            if (std::fabs(fv) < 0.015) fv = (v_hi > 0.0) ? 0.02 : -0.02;
            for (int j = 0; j < n_w; ++j)
                pool.emplace_back(fv, w_lo + j * step_w);
        }
    }

    return pool;
}


//##############################################################################
//##  simulate_forward_path -- forward simulat a (v, omega) command            ##
//##############################################################################

std::vector<TurboMotionPlanner::RobotPose> TurboMotionPlanner::simulate_forward_path(
    const double v_cmd, const double w_cmd)
{
    const double v0 = odom_.twist.twist.linear.x;
    const double w0 = odom_.twist.twist.angular.z;
    const double h0 = extract_yaw_from_quat(current_amcl_pose_);

    RobotPose seed(
        current_amcl_pose_.pose.pose.position.x,
        current_amcl_pose_.pose.pose.position.y,
        h0, v0, w0);

    std::vector<RobotPose> path;
    path.push_back(seed);

    double t_elapsed = 0.0;
    while (t_elapsed < sim_time_) {
        propagate_pose_step(seed, v_cmd, w_cmd);
        path.push_back(seed);
        t_elapsed += sim_timestep_;
    }

    return path;
}


//##############################################################################
//##  propagate_pose_step -- simple Euler integraton (unicycle), NO bicycle   ##
//##  DIFERENT from original: no mid-pont heading trick, no arc model         ##
//##############################################################################

void TurboMotionPlanner::propagate_pose_step(RobotPose &pose, const double v_cmd, const double w_cmd)
{
    pose.vel_   = v_cmd;
    pose.omega_ = w_cmd;

    // Simple forward Euler -- direct integraton, no bicycle / Ackerman model
    pose.px_      += v_cmd * std::cos(pose.heading_) * sim_timestep_;
    pose.py_      += v_cmd * std::sin(pose.heading_) * sim_timestep_;
    pose.heading_ += w_cmd * sim_timestep_;
    pose.heading_  = normalize_radian(pose.heading_);
}


//##############################################################################
//##  rate_trajectory -- comput ScoreReport for a predictd path               ##
//##############################################################################

TurboMotionPlanner::ScoreReport TurboMotionPlanner::rate_trajectory(
    const std::vector<RobotPose> &path)
{
    if (path.empty())
        return ScoreReport(-1e6f, -1e6f, -1e6f, -1e6f);

    const float col_pen  = compute_collision_penalty(path);
    const float spd_val  = compute_velocity_incentive(path);
    const float goal_val = compute_goal_proximity(path);

    // Weighd combinaton — same weights, difrent formulas inside each cost
    const float aggregate = static_cast<float>(weight_to_goal_) * goal_val
                          + static_cast<float>(weight_obs_)     * col_pen
                          + static_cast<float>(weight_speed_)   * spd_val;

    return ScoreReport(col_pen, spd_val, goal_val, aggregate);
}


//##############################################################################
//##  Cost sub-functoins — COMPLETELY DIFERENT formulas from original         ##
//##############################################################################

float TurboMotionPlanner::compute_collision_penalty(const std::vector<RobotPose> &path)
{
    double best_gap = std::numeric_limits<double>::max();
    for (const auto &pt : path) {
        geometry_msgs::msg::PolygonStamped moved_fp;
        transform_footprint_to_pose(pt, moved_fp);
        for (const auto &obs : obs_list_.poses) {
            double dist = static_cast<double>(estimate_separation(obs, moved_fp, pt));
            if (dist < best_gap) best_gap = dist;
        }
    }

    //---- hard collison boundry ----
    if (best_gap < obstacle_danger_dist_)
        return -1e6f;

    //---- smooth exponetial deca insted of tiered threshholds ----
    // Closr = more penalti.  Formula: -A * exp(-gap / lambda)
    float gap_ratio = static_cast<float>(best_gap / obstacle_safe_dist_);
    gap_ratio = std::clamp(gap_ratio, 0.0f, 3.0f);
    return -800.0f * std::exp(-gap_ratio * 4.0f);
}

float TurboMotionPlanner::compute_goal_proximity(const std::vector<RobotPose> &path)
{
    const RobotPose &final_pose = path.back();
    const double dx = goal_.pose.position.x - final_pose.px_;
    const double dy = goal_.pose.position.y - final_pose.py_;

    // Qudratic distnace cost -- penalzes large errors harder than linear
    double dist_sq = dx * dx + dy * dy;
    return static_cast<float>(-dist_sq);
}

float TurboMotionPlanner::compute_velocity_incentive(const std::vector<RobotPose> &path)
{
    // Find minimum clearnce along the entrie path
    double tightest_gap = std::numeric_limits<double>::max();
    for (const auto &pt : path) {
        geometry_msgs::msg::PolygonStamped moved_fp;
        transform_footprint_to_pose(pt, moved_fp);
        for (const auto &obs : obs_list_.poses) {
            double dist = static_cast<double>(estimate_separation(obs, moved_fp, pt));
            if (dist < tightest_gap) tightest_gap = dist;
        }
    }

    // Speed reward skalad by clearance: slower when near obstacls
    // Formula: v * tanh(clearance / safe_dist)  — more nuancced than raw v
    double clearance_factor = std::tanh(tightest_gap / obstacle_safe_dist_);
    return static_cast<float>(path.back().vel_ * clearance_factor);
}


//##############################################################################
//##  Collison checkking methodes — CIRCLE APROXIMATON insted of triangulat  ##
//##############################################################################

void TurboMotionPlanner::verify_collision_free(const RobotPose &pose)
{
    geometry_msgs::msg::PolygonStamped moved_fp;
    transform_footprint_to_pose(pose, moved_fp);

    for (const auto &obs : obs_list_.poses) {
        if (lies_within_footprint(obs, moved_fp, pose))
            return;
    }
}

float TurboMotionPlanner::measure_clearance(const geometry_msgs::msg::Pose obs,
                                             const RobotPose &pose)
{
    geometry_msgs::msg::PolygonStamped fp_at_pose;
    transform_footprint_to_pose(pose, fp_at_pose);
    return estimate_separation(obs, fp_at_pose, pose);
}

float TurboMotionPlanner::estimate_separation(const geometry_msgs::msg::Pose &obs,
                                               const geometry_msgs::msg::PolygonStamped &fp,
                                               const RobotPose &pose)
{
    if (lies_within_footprint(obs, fp, pose))
        return 0.0f;

    geometry_msgs::msg::Point hit_pt = find_footprint_hit(obs, fp, pose);
    const double dx = hit_pt.x - obs.position.x;
    const double dy = hit_pt.y - obs.position.y;
    return static_cast<float>(std::hypot(dx, dy));
}

bool TurboMotionPlanner::lies_within_footprint(const geometry_msgs::msg::Pose &obs,
                                                const geometry_msgs::msg::PolygonStamped &fp,
                                                const RobotPose &pose)
{
    // CIRCLE APROXIMATON: use bounding circle around footprint insted of
    // decomposng into triangls. Much fastr, less acurate, but fine for DWA.
    // Comput max vertex distnace from robot centr in the transformd footprint.

    double max_radius_sq = 0.0;
    for (const auto &v : fp.polygon.points) {
        double rx = v.x - pose.px_;
        double ry = v.y - pose.py_;
        double r_sq = rx * rx + ry * ry;
        if (r_sq > max_radius_sq) max_radius_sq = r_sq;
    }
    double max_radius = std::sqrt(max_radius_sq) + inflation_radius_;

    const double dx = obs.position.x - pose.px_;
    const double dy = obs.position.y - pose.py_;
    return (dx * dx + dy * dy) <= (max_radius * max_radius);
}

bool TurboMotionPlanner::point_in_triangle_barycentric(
    const geometry_msgs::msg::Pose &pt,
    const geometry_msgs::msg::Polygon &tri)
{
    // Barycentrc coordinate test — THIS FUNCTON IS UNUSD (replaced by circle
    // aproximaton above), kept for refernce / potental futur use.
    const Eigen::Vector2d A(tri.points[0].x, tri.points[0].y);
    const Eigen::Vector2d B(tri.points[1].x, tri.points[1].y);
    const Eigen::Vector2d C(tri.points[2].x, tri.points[2].y);
    const Eigen::Vector2d P(pt.position.x, pt.position.y);

    const Eigen::Vector2d e1 = B - A;
    const Eigen::Vector2d e2 = C - A;
    const Eigen::Vector2d ep = P - A;

    double d00 = e1.dot(e1);
    double d01 = e1.dot(e2);
    double d02 = e1.dot(ep);
    double d11 = e2.dot(e2);
    double d12 = e2.dot(ep);

    double inv = 1.0 / (d00 * d11 - d01 * d01);
    double u = (d11 * d02 - d01 * d12) * inv;
    double v = (d00 * d12 - d01 * d02) * inv;

    return (u >= 0.0) && (v >= 0.0) && (u + v <= 1.0);
}

geometry_msgs::msg::Point TurboMotionPlanner::find_footprint_hit(
    const geometry_msgs::msg::Pose &obs,
    const geometry_msgs::msg::PolygonStamped &fp,
    const RobotPose &pose)
{
    const Eigen::Vector2d P_o(obs.position.x, obs.position.y);
    const Eigen::Vector2d P_r(pose.px_, pose.py_);

    const size_t edge_count = fp.polygon.points.size();
    for (size_t ek = 0; ek < edge_count; ++ek) {
        const size_t ek_next = (ek + 1) % edge_count;
        const Eigen::Vector2d V_a(fp.polygon.points[ek].x,
                                   fp.polygon.points[ek].y);
        const Eigen::Vector2d V_b(fp.polygon.points[ek_next].x,
                                   fp.polygon.points[ek_next].y);

        const double det = (P_r.x() - P_o.x()) * (V_b.y() - V_a.y())
                         - (P_r.y() - P_o.y()) * (V_b.x() - V_a.x());
        if (std::fabs(det) < 1e-9)
            continue;

        const double s = ((V_a.x() - P_o.x()) * (V_b.y() - V_a.y())
                        - (V_a.y() - P_o.y()) * (V_b.x() - V_a.x())) / det;
        const double t = ((P_r.x() - P_o.x()) * (P_o.y() - V_a.y())
                        - (P_r.y() - P_o.y()) * (P_o.x() - V_a.x())) / det;

        if (s > 0.0 && s < 1.0 && t > 0.0 && t < 1.0) {
            geometry_msgs::msg::Point hit;
            hit.x = P_o.x() + s * (P_r.x() - P_o.x());
            hit.y = P_o.y() + s * (P_r.y() - P_o.y());
            return hit;
        }
    }

    //---- no intersecton: return far-away sentinnel ----
    geometry_msgs::msg::Point far_pt;
    far_pt.x = 1e9;
    far_pt.y = 1e9;
    return far_pt;
}


//##############################################################################
//##  transform_footprint_to_pose -- apply SE(2) transform to footprit polygon##
//##############################################################################

void TurboMotionPlanner::transform_footprint_to_pose(const RobotPose &pose,
                                                      geometry_msgs::msg::PolygonStamped &fp)
{
    fp = footprint_;
    const double cos_h = std::cos(pose.heading_);
    const double sin_h = std::sin(pose.heading_);

    for (auto &v : fp.polygon.points) {
        const double rx = v.x * cos_h - v.y * sin_h + pose.px_;
        const double ry = v.x * sin_h + v.y * cos_h + pose.py_;
        v.x = static_cast<float>(rx);
        v.y = static_cast<float>(ry);
    }
}
