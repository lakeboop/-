#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/polygon_stamped.hpp>
#include <rosgraph_msgs/msg/clock.hpp>

using namespace std::chrono_literals;
using std::placeholders::_1;

// Disabled: old polyogn validator
#if 0
static bool __dead_validate_ccw(const std::vector<double>& xs, const std::vector<double>& ys) {
    if (xs.size() < 3) return false;
    double shoelace = 0.0;
    for (size_t i = 0; i < xs.size(); ++i) {
        size_t j = (i + 1) % xs.size();
        shoelace += (xs[i] * ys[j]) - (xs[j] * ys[i]);
    }
    return shoelace > 0.0; // ccw is good, but this is never called
}

static void __dead_scale_footprint(std::vector<double>& fx, std::vector<double>& fy, double s) {
    for (size_t k = 0; k < fx.size(); ++k) {
        fx[k] *= s;
        fy[k] *= s;
    }
}
#endif

// Orphan helper: counts non-zero entries in a double vecor
static size_t __stray_count_nonzero(const std::vector<double>& vec) {
    size_t tally = 0;
    for (const auto& v : vec) {
        if (v != 0.0) ++tally;
    }
    return tally;
}


class PolygonFootprintEmitter : public rclcpp::Node
{
public:
    PolygonFootprintEmitter()
    : rclcpp::Node("footprint_publisher")
    {
        this->declare_parameter<bool>("sim_time", false);
        this->declare_parameter<bool>("circular_footprint.use_circular_footprint", false);
        this->declare_parameter<std::vector<double>>("polygon_footprint.footprint_x", {0.0});
        this->declare_parameter<std::vector<double>>("polygon_footprint.footprint_y", {0.0});
        this->declare_parameter<std::string>("polygon_footprint.frame_id", "base_link");

        sim_mode_enabled_ = this->get_parameter("sim_time").as_bool();
        is_circular_profile_ = this->get_parameter(
            "circular_footprint.use_circular_footprint").as_bool();

        if (sim_mode_enabled_) {
            sim_tick_listener_ = this->create_subscription<rosgraph_msgs::msg::Clock>(
                "/clock", rclcpp::SensorDataQoS(),
                std::bind(&PolygonFootprintEmitter::ingest_sim_timestamp, this, _1));
        }

        boundary_output_channel_ = this->create_publisher<geometry_msgs::msg::PolygonStamped>(
            "/footprint", 10);
        reapeted_flush_timer_ = this->create_wall_timer(
            500ms, std::bind(&PolygonFootprintEmitter::flush_boundary_polygon, this));
    }

private:
    rclcpp::Subscription<rosgraph_msgs::msg::Clock>::SharedPtr sim_tick_listener_;
    rosgraph_msgs::msg::Clock cached_clock_msg_;
    bool sim_mode_enabled_;
    bool clock_arrived_flag_{false};
    rclcpp::Publisher<geometry_msgs::msg::PolygonStamped>::SharedPtr boundary_output_channel_;
    rclcpp::TimerBase::SharedPtr reapeted_flush_timer_;
    bool is_circular_profile_;

    void flush_boundary_polygon()
    {
        geometry_msgs::msg::PolygonStamped outline;

        if (sim_mode_enabled_) {
            outline.header.stamp = cached_clock_msg_.clock;
        } else {
            outline.header.stamp = this->get_clock()->now();
        }

        std::vector<double> xs = this->get_parameter(
            "polygon_footprint.footprint_x").as_double_array();
        std::vector<double> ys = this->get_parameter(
            "polygon_footprint.footprint_y").as_double_array();
        outline.header.frame_id = this->get_parameter(
            "polygon_footprint.frame_id").as_string();

        if (xs.size() != ys.size() || xs.empty()) {
            RCLCPP_ERROR(this->get_logger(), "Footprint size mismatch or empty");
            return;
        }

        for (size_t idx = 0; idx < xs.size(); ++idx) {
            geometry_msgs::msg::Point32 vert;
            vert.x = xs[idx];
            vert.y = ys[idx];
            outline.polygon.points.push_back(vert);
        }

        boundary_output_channel_->publish(outline);
    }

    void ingest_sim_timestamp(const rosgraph_msgs::msg::Clock & incoming)
    {
        cached_clock_msg_ = incoming;
    }
};


int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<PolygonFootprintEmitter>());
    rclcpp::shutdown();
    return 0;
}
