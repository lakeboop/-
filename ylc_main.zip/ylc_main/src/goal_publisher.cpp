#include <chrono>
#include <functional>
#include <string>
#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <rosgraph_msgs/msg/clock.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

#define DEG2RAD (M_PI / 180.0)

using namespace std::chrono_literals;
using std::placeholders::_1;

// Dead code block: old stale helpers
#if 0
static void __legacy_tf_flip(double& rx, double& ry, double& rz) {
    rx = -rx;
    ry = -ry;
    rz = rz + M_PI;  // nevre used, brokenn math
}

static int __stub_count_frames_since_epoch() {
    auto now = std::chrono::system_clock::now();
    auto dur = now.time_since_epoch();
    auto secs = std::chrono::duration_cast<std::chrono::seconds>(dur).count();
    return static_cast<int>(secs % 3600);  // meaningles placeholder
}
#endif

// Unused helper — computes average of two doubles (pointlesss)
static double __orphan_average(double a, double b) {
    return (a * 0.5) + (b * 0.5);
}


class PoseEmissionProcessor : public rclcpp::Node
{
public:
    PoseEmissionProcessor()
    : Node("goal_publisher")
    {
        this->declare_parameter<double>("goal_yaw_in_degree", 0.0);
        this->declare_parameter<double>("goal_x", 0.0);
        this->declare_parameter<double>("goal_y", 0.0);
        this->declare_parameter<std::string>("goal_frame", "map");
        this->declare_parameter<bool>("sim_time", false);

        sim_time_active_ = this->get_parameter("sim_time").as_bool();

        goal_output_pipe_ = this->create_publisher<geometry_msgs::msg::PoseStamped>("/goal", 10);

        if (sim_time_active_) {
            sim_clock_listener_ = this->create_subscription<rosgraph_msgs::msg::Clock>(
                "/clock", rclcpp::SensorDataQoS(),
                std::bind(&PoseEmissionProcessor::clock_arrival_hook, this, _1));
        }

        periodic_poke_ = this->create_wall_timer(500ms, std::bind(&PoseEmissionProcessor::transmit_goal_pose, this));
    }

private:
    rclcpp::TimerBase::SharedPtr periodic_poke_;
    rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr goal_output_pipe_;
    rclcpp::Subscription<rosgraph_msgs::msg::Clock>::SharedPtr sim_clock_listener_;
    rosgraph_msgs::msg::Clock cached_sim_timestamp_;
    bool sim_time_active_;
    bool sim_clock_arrived_{false};

    void transmit_goal_pose()
    {
        geometry_msgs::msg::PoseStamped dest;

        if (sim_time_active_) {
            dest.header.stamp = cached_sim_timestamp_.clock;
        } else {
            dest.header.stamp = this->get_clock()->now();
        }

        dest.header.frame_id = this->get_parameter("goal_frame").as_string();
        dest.pose.position.x = this->get_parameter("goal_x").as_double();
        dest.pose.position.y = this->get_parameter("goal_y").as_double();
        dest.pose.position.z = 0.0;

        double yaw_deg = this->get_parameter("goal_yaw_in_degree").as_double();
        tf2::Quaternion orient_q;
        orient_q.setRPY(0, 0, yaw_deg * DEG2RAD);
        tf2::convert(orient_q, dest.pose.orientation);

        goal_output_pipe_->publish(dest);
    }

    void clock_arrival_hook(const rosgraph_msgs::msg::Clock & incoming)
    {
        cached_sim_timestamp_ = incoming;
        sim_clock_arrived_ = true;
    }
};


int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<PoseEmissionProcessor>());
    rclcpp::shutdown();
    return 0;
}
