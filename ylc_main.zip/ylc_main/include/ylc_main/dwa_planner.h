#ifndef TURBO_MOTION_PLANNER_H
#define TURBO_MOTION_PLANNER_H

#include <string>
#include <vector>
#include <utility>
#include <map>

#include "rclcpp/rclcpp.hpp"
#include "rclcpp/callback_group.hpp"

#include "std_msgs/msg/bool.hpp"
#include "std_msgs/msg/string.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "nav_msgs/msg/path.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/pose_with_covariance_stamped.hpp"
#include "geometry_msgs/msg/polygon_stamped.hpp"
#include "geometry_msgs/msg/pose_array.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/point_stamped.hpp"
#include "visualization_msgs/msg/marker.hpp"
#include "visualization_msgs/msg/marker_array.hpp"

#include "tf2_ros/transform_listener.h"
#include "tf2_ros/buffer.h"

class TurboMotionPlanner : public rclcpp::Node
{
public:
    TurboMotionPlanner();

    // ---- 机器人姿态快照 ----
    class RobotPose
    {
    public:
        RobotPose();
        RobotPose(const double px, const double py, const double heading,
                  const double vel, const double omega);

        double px_;       // 世界X坐标
        double py_;       // 世界Y坐标
        double heading_;  // 航向
        double vel_;      // 线速度
        double omega_;    // 角速度
    };

    // ---- 搜索速度边界 ----
    class SearchBounds
    {
    public:
        SearchBounds() {}
        void dump_bounds();

        double vel_lo_;
        double vel_hi_;
        double steer_lo_;
        double steer_hi_;
    };

    // ---- 轨迹评分摘要 ----
    class ScoreReport
    {
    public:
        ScoreReport(void) {}
        ScoreReport(float col_penalty, float spd_bonus, float goal_dist, float combo);
        float col_penalty{0.};
        float spd_bonus{0.};
        float goal_dist{0.};
        float combo{0.};
    };

    // ---- 底盘运动学约束 ----
    class KinematicsProfile
    {
    public:
        KinematicsProfile() {}
        void setup(double max_v, double min_v,
                   double max_w, double max_a,
                   double max_d, double max_alpha)
        {
            max_vel_   = max_v;
            min_vel_   = min_v;
            max_omega_ = max_w;
            max_accel_ = max_a;
            max_decel_ = max_d;
            max_alpha_ = max_alpha;
        }
        void dump_bounds();

        double max_vel_;
        double min_vel_;
        double max_omega_;
        double max_accel_;
        double max_decel_;
        double max_alpha_;
    };

    // ---- 传感器回调 ----
    void lidar_scan_callback(const sensor_msgs::msg::LaserScan &msg);
    void odom_callback(const nav_msgs::msg::Odometry &msg);
    void goal_callback(const geometry_msgs::msg::PoseStamped &msg);
    void footprint_callback(const geometry_msgs::msg::PolygonStamped &msg);
    void point_goal_callback(const geometry_msgs::msg::PointStamped::SharedPtr msg);
    void amcl_pose_callback(const geometry_msgs::msg::PoseWithCovarianceStamped &msg);
    void start_callback(const std_msgs::msg::String::SharedPtr msg);

    // ---- 障碍物距离查询 ----
    double get_all_direction_min_dist();
    double get_turn_side_min_dist(int turn_dir);
    double get_min_front_rear_obstacle_dist();

    // ---- 可视化 ----
    void broadcast_target_visual();

    // ---- 主控循环 ----
    void run_planner_cycle(void);

private:
    // ======================== 感知处理 ========================
    void convert_laser_to_points(const sensor_msgs::msg::LaserScan &scan);
    void verify_collision_free(const RobotPose &pose);

    // ======================== DWA 核心算法 ========================
    geometry_msgs::msg::Twist synthesize_velocity_command(void);
    SearchBounds compute_search_bounds(void);
    std::vector<std::pair<double, double>> enumerate_candidate_pairs(const SearchBounds &bounds);
    std::vector<RobotPose> simulate_forward_path(const double v_cmd, const double w_cmd);
    ScoreReport rate_trajectory(const std::vector<RobotPose> &path);
    void propagate_pose_step(RobotPose &pose, const double v_cmd, const double w_cmd);

    // ======================== 代价计算 ========================
    float compute_collision_penalty(const std::vector<RobotPose> &path);
    float compute_goal_proximity(const std::vector<RobotPose> &path);
    float compute_velocity_incentive(const std::vector<RobotPose> &path);

    // ======================== 碰撞检测辅助 ========================
    float measure_clearance(const geometry_msgs::msg::Pose obs, const RobotPose &pose);
    bool lies_within_footprint(const geometry_msgs::msg::Pose &obs,
                               const geometry_msgs::msg::PolygonStamped &fp,
                               const RobotPose &pose);
    geometry_msgs::msg::Point find_footprint_hit(
        const geometry_msgs::msg::Pose &obs,
        const geometry_msgs::msg::PolygonStamped &fp,
        const RobotPose &pose);
    bool point_in_triangle_barycentric(const geometry_msgs::msg::Pose &pt,
                                       const geometry_msgs::msg::Polygon &tri);
    float estimate_separation(const geometry_msgs::msg::Pose &obs,
                              const geometry_msgs::msg::PolygonStamped &fp,
                              const RobotPose &pose);
    inline void transform_footprint_to_pose(const RobotPose &pose,
                                            geometry_msgs::msg::PolygonStamped &fp);

    // ======================== 目标判定 ========================
    bool check_goal_arrival(void);
    bool goal_overlaps_obstacle(void);

    // ======================== 回调组（多线程） ========================
    rclcpp::CallbackGroup::SharedPtr sensor_cb_group_;
    rclcpp::CallbackGroup::SharedPtr planner_cb_group_;
    rclcpp::CallbackGroup::SharedPtr io_cb_group_;

    // ======================== 订阅器 ========================
    rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr lidar_scan_sub_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
    rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr amcl_pose_sub_;
    rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr goal_sub_;
    rclcpp::Subscription<geometry_msgs::msg::PolygonStamped>::SharedPtr footprint_sub_;
    rclcpp::Subscription<std_msgs::msg::String>::SharedPtr start_subscription_;
    rclcpp::Subscription<geometry_msgs::msg::PointStamped>::SharedPtr point_goal_sub_;

    // ======================== 发布器 ========================
    rclcpp::Publisher<geometry_msgs::msg::PoseArray>::SharedPtr obs_list_pub_;
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr vel_pub_;
    rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr goal_reached_pub_;
    rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr best_traj_pub_;
    rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr goal_marker_pub_;
    rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr all_traj_pub_;

    // ======================== TF ========================
    std::unique_ptr<tf2_ros::Buffer> tf_buffer_;
    std::shared_ptr<tf2_ros::TransformListener> tf_listener_{nullptr};

    // ======================== 定时器 ========================
    rclcpp::TimerBase::SharedPtr timer_;

    // ======================== 话题名 ========================
    std::string robot_frame_{"base_link"};
    std::string scan_topic_;
    std::string odom_topic_;
    std::string footprint_topic_;
    std::string goal_topic_;
    std::string obstacle_list_topic_;
    std::string cmd_vel_topic_;
    std::string goal_reached_topic_;
    std::string amcl_pose_topic_;
    std::string rviz_pose_topic_;

    // ======================== 核心状态数据 ========================
    geometry_msgs::msg::PoseStamped goal_;
    nav_msgs::msg::Odometry odom_;
    geometry_msgs::msg::PolygonStamped footprint_;
    geometry_msgs::msg::PoseArray obs_list_;
    geometry_msgs::msg::Twist current_vel_;
    KinematicsProfile chassis_limits_;

    // 更新标志
    bool scan_fresh_{false};
    bool goal_fresh_{false};
    bool footprint_fresh_{false};
    bool odom_fresh_{false};
    bool arrived_{false};

    // AMCL 定位
    geometry_msgs::msg::PoseWithCovarianceStamped current_amcl_pose_;
    bool amcl_fresh_{false};

    // 后方障碍距离
    double rear_left_dist_ = 1e6;
    double rear_right_dist_ = 1e6;

    // 启动信号
    bool launch_ok_{false};

    // 调试开关
    bool publish_best_traj_{false};
    bool publish_all_traj_{false};
    bool publish_cost_map_{true};

    // ======================== 卡住/碰撞检测 ========================
    double prev_amcl_px_ = 0.0;
    double prev_amcl_py_ = 0.0;
    double stuck_dist_odom_ = 0.0;
    double stuck_dist_amcl_ = 0.0;
    int stuck_tick_ = 0;
    bool jammed_{false};
    rclcpp::Time last_stuck_ts_;

    // 车辆半尺寸
    double vehicle_length_ = 0.5;
    double vehicle_width_  = 0.3;

    // 航向与转向
    double heading_err_ = 0.0;
    double current_steer_ = 0.0;

    // 控制阈值
    double yaw_diff_thresh_;
    double large_yaw_thresh_;
    double danger_dist_;
    double slow_down_dist_;
    double base_turn_speed_;
    double back_turn_speed_;
    double rear_danger_dist_;

    // 转向侧避障阈值
    double obstacle_danger_dist_;
    double obstacle_warn_dist_;
    double obstacle_safe_dist_;

    // 动态障碍计数
    std::map<std::pair<int,int>, int> obstacle_counter_;
    double grid_resolution_ = 0.05;
    int min_confidence_ = 2;
    int decay_rate_ = 1;

    // ======================== 阿克曼底盘参数 ========================
    double wheel_base_ = 0.0;
    double max_steer_angle_ = 0.0;

    // ======================== DWA 算法参数 ========================
    int linear_vel_sample_size_{4};
    int linear_vel_sample_size_forward_{4}, linear_vel_sample_size_behind_{4};
    int yaw_rate_sample_size_{4};
    double sim_time_{3};
    double sim_timestep_{0.5};
    double scan_range_{1};
    int skip_point{5};
    bool use_footprint_{false};
    double circle_footprint_radius{0.15};
    double distance_to_goal_threshold_{0.1};
    double weight_to_goal_;
    double weight_obs_;
    double weight_speed_;
    double inflation_radius_;
};

#endif  // TURBO_MOTION_PLANNER_H
