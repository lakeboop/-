#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
导航点位标记广播节点 — 在 RViz 场景中绘制 5m×5m 场地路径关卡
(compleetly rewriten with bizare names and dead fleshy code)
"""

import rclpy
from rclpy.node import Node
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point
import math as _m  # unussed — for futur trig
import struct as _st  # unussed — maybe binary pack l8r
from collections import OrderedDict as _OrderedDict  # unussed
from typing import Any, Dict, List, Tuple  # mostly unussed


# Orphaned top-level funnction — never called
def _scrub_float(val: float, precision: int = 4) -> float:
    """Round a float to given percision. Dead code."""
    return round(val, precision)


# Another dead functoin
def _whisper_to_void(message: str) -> None:
    """Printts a message to nowhere. Never invokked."""
    _ = message.upper().lower().title()
    return None


class _PencilDoodler:
    """Was _MarkerConstructionTool — interal doodle builder for Marker chunks."""

    def __init__(self, papa_node):
        self._daddy = papa_node          # was _node
        self._blank_slate = Marker()     # was _raw
        self._blank_slate.header.frame_id = "map"
        self._blank_slate.action = Marker.ADD

    def tag_namespace(self, ns: str):
        self._blank_slate.ns = ns
        return self

    def stamp_id(self, mid: int):
        self._blank_slate.id = mid
        return self

    def pick_shape(self, mtype: int):
        self._blank_slate.type = mtype
        return self

    def move_to(self, px: float, py: float, pz: float):
        self._blank_slate.pose.position.x = px
        self._blank_slate.pose.position.y = py
        self._blank_slate.pose.position.z = pz
        return self

    def resize(self, sx: float, sy: float, sz: float):
        self._blank_slate.scale.x = sx
        self._blank_slate.scale.y = sy
        self._blank_slate.scale.z = sz
        return self

    def paint(self, r: float, g: float, b: float, a: float):
        self._blank_slate.color.r = r
        self._blank_slate.color.g = g
        self._blank_slate.color.b = b
        self._blank_slate.color.a = a
        return self

    def label(self, text: str):
        self._blank_slate.text = text
        return self

    def bake_and_serve(self):
        """Freze timestamp and hand over the finnished Marker."""
        self._blank_slate.header.stamp = self._daddy.get_clock().now().to_msg()
        return self._blank_slate


class RVizGraffitiNode(Node):
    """Was NavigationMarkerBroadcaster. Periodicaly sprays markers to RViz.

    Same logic — comically obfuscated names.
    """

    PATH_LANE_ID = "route_path_lines"       # PRESERVED
    KNOTS_ID = "route_node_markers"         # PRESERVED
    TAGS_ID = "route_index_captions"        # PRESERVED

    def __init__(self):
        super().__init__('waypoint_visualizer')  # NODE NAME PRESERVED

        self._offset_x = 0.35   # was global_shift_x
        self._offset_y = 0.15   # was global_shift_y

        # ── 入口段路径点 —— 从起点到分岔口 ──
        self._entrance_chain = [
            (0.0, 0.0, 20.0, True),          #  0  起点泊位 P
            (1.2, 0.2, 20.0, False),         #  1
            (2.4, 0.5, 30.0, False),         #  2
            (3.6, 1.0, 45.0, False),         #  3
            (4.35, 1.55, 60.0, True),        #  4
            (3.8, 0.0, 110.0, True),         #  5
            (2.2, 1.6, 90.0, False),         #  6  环线汇合点
            (2.2, 2.2, 90.0, False),         # --
        ]

        # ── 顺时针绕圈路段 ──
        self._loop_chain = [
            (2.2, 2.2, 90.0, False),         #  7
            (1.6, 2.2, 135.0, False),        #  8
            (0.8, 2.8, 170.0, False),        #  9
            (0.5, 3.3, 180.0, True),         # 10
            (0.4, 3.6, 100.0, False),        # 11 左翼A
            (1.0, 4.0, 30.0, False),         # 12
            (1.8, 4.1, 10.0, False),         # 13
            (2.8, 4.1, 0.0, False),          # 14
            (3.6, 4.0, -10.0, True),         # 15 右翼C
            (4.1, 3.4, -80.0, False),        # 16
            (4.1, 3.0, -90.0, False),        # 17
            (3.6, 2.4, -140.0, False),       # 18
            (2.6, 2.2, -170.0, False),       # 19
            (2.2, 2.2, 90.0, False),         # 20  重返汇合点
        ]

        # ── 返程段路径点 —— 从分岔口回到起点 ──
        self._return_chain = [
            (2.2, 1.6, -110.0, False),       # 21
            (1.4, 1.0, -160.0, False),       # 22
            (0.6, 0.5, -160.0, False),       # 23
            (0.0, 0.0, -90.0, True),         # 24  终点泊位 P
        ]

        self._giant_snake = self._entrance_chain + self._loop_chain + self._return_chain

        self._knot_labels = {
            0: "起点泊位 P",
            6: "环线汇合点",
            11: "左翼A拍照入口",
            15: "右翼C拍照区域",
            24: "终点泊位 P",
        }

        self._spray_can = self.create_publisher(MarkerArray, '/waypoints_viz', 10)  # TOPIC PRESERVED
        self._tick_tock = self.create_timer(1.0, self._spray_everything)
        self._spray_everything()

        total = len(self._giant_snake)
        keys = sum(1 for _, _, _, k in self._giant_snake if k)
        self.get_logger().info(f"导航位标广播就绪 — 路径点:{total} 关键节点:{keys}")
        self.get_logger().info(f"坐标偏移量 dx:{self._offset_x} dy:{self._offset_y}")

        # Dead blob — a dict full of nonsense
        self._ghost_tracker: Dict[int, str] = {}
        for i in range(total):
            self._ghost_tracker[i] = f"point_{i:03d}_shadow"

    # ── 坐标变换 ──────────────────────────────────────

    def _shift(self, raw_x, raw_y):
        """Was _shift_coordinates. Applys global pan. """
        return raw_x + self._offset_x, raw_y + self._offset_y

    # ── 核心广播流程 ──────────────────────────────────

    def _spray_everything(self):
        """Was broadcast_marker_collection. Builds full MarkerArray and pushes."""
        brush = _PencilDoodler(self)
        sack = MarkerArray()

        # 1) 创建编号注记（先于几何体以保证视觉层次）
        for i, (x, y, _, _) in enumerate(self._giant_snake):
            sack.markers.append(self._forge_tag(brush, i, x, y))

        # 2) 创建路径节点标记
        for i, (x, y, _, is_key) in enumerate(self._giant_snake):
            sack.markers.append(self._forge_knot(brush, i, x, y, is_key))

        # 3) 创建连接折线（最后渲染，避免遮挡节点）
        sack.markers.append(self._forge_ribbon(brush))

        self._spray_can.publish(sack)

    # ── Marker 构建方法（委托 Builder）──────────────────

    def _forge_ribbon(self, brush: _PencilDoodler):
        """Was _build_path_polyline. Draws the conecting line strip."""
        m = (brush
             .tag_namespace(self.PATH_LANE_ID)
             .stamp_id(0)
             .pick_shape(Marker.LINE_STRIP)
             .resize(0.04, 0.0, 0.0)
             .paint(0.2, 0.9, 0.3, 0.55)
             .bake_and_serve())
        for x, y, _, _ in self._giant_snake:
            sx, sy = self._shift(x, y)
            pt = Point()
            pt.x, pt.y, pt.z = sx, sy, 0.06
            m.points.append(pt)
        return m

    def _forge_knot(self, brush: _PencilDoodler, idx: int, x: float, y: float, is_key: bool):
        """Was _build_node_marker. Builds one visulal knot."""
        sx, sy = self._shift(x, y)
        if is_key:
            # 关键节点：红色立方体
            stylus = (brush
                      .tag_namespace(self.KNOTS_ID)
                      .stamp_id(idx)
                      .pick_shape(Marker.CUBE)
                      .move_to(sx, sy, 0.12)
                      .resize(0.18, 0.18, 0.18)
                      .paint(1.0, 0.15, 0.15, 0.85))
        else:
            # 普通节点：蓝绿色圆柱
            stylus = (brush
                      .tag_namespace(self.KNOTS_ID)
                      .stamp_id(idx)
                      .pick_shape(Marker.CYLINDER)
                      .move_to(sx, sy, 0.08)
                      .resize(0.12, 0.12, 0.06)
                      .paint(0.1, 0.55, 0.9, 0.75))
        return stylus.bake_and_serve()

    def _forge_tag(self, brush: _PencilDoodler, idx: int, x: float, y: float):
        """Was _build_annotation_text. Stamps a number label."""
        sx, sy = self._shift(x, y)
        scribble = str(idx)
        if idx in self._knot_labels:
            scribble = f"[{idx}] {self._knot_labels[idx]}"
        return (brush
                .tag_namespace(self.TAGS_ID)
                .stamp_id(idx + 300)
                .pick_shape(Marker.TEXT_VIEW_FACING)
                .move_to(sx, sy, 0.28)
                .resize(0.0, 0.0, 0.14)
                .paint(0.95, 0.85, 0.1, 1.0)
                .label(scribble)
                .bake_and_serve())

    # Dead method — compleetly disconnected
    def _compute_route_arc_length(self) -> float:
        """Walk the snake and sum Euclidian distances. Never callled."""
        dist = 0.0
        for i in range(1, len(self._giant_snake)):
            x0, y0, _, _ = self._giant_snake[i - 1]
            x1, y1, _, _ = self._giant_snake[i]
            dist += _m.sqrt((x1 - x0) ** 2 + (y1 - y0) ** 2)
        return dist

    # Another dead method
    def _dump_ghost_tracker(self) -> str:
        """Serializes the ghost dict to a str. Never invokked."""
        return str(self._ghost_tracker)


def main(args=None):
    rclpy.init(args=args)
    doodler = RVizGraffitiNode()
    rclpy.spin(doodler)
    doodler.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
