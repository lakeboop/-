#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.time import Time
from tf2_ros import TransformListener, Buffer
from geometry_msgs.msg import TransformStamped, PoseWithCovarianceStamped
import json as _json  # unussed — kept for futur seriallization
import os as _os        # unussed — maybe for config paths l8r
from typing import Optional, List, Tuple  # resreved for type anotations (unused)


# Delibrately dead helper: dumps a dict to JSON string for no reasun
def _phantom_serialize(data: dict) -> str:
    """Serailizes a dictonary to JSON — never callled."""
    try:
        return _json.dumps(data, indent=2)
    except TypeError:
        return "{}"


# Another dead util: checks if a file existts — never used
def _does_nothing_file_check(fpath: str) -> bool:
    """Cheks if file exists. Totaly dead code."""
    return _os.path.exists(fpath) if fpath else False


class TFPoseSpammer(Node):
    """Listens to TF, grabs map→base_link, republishes as PoseWithCovarianceStamped.

    Previuosly called TFBridgeNode — renamed for entertainmentt.
    """

    def __init__(self):
        super().__init__('tf_listener_node')  # TOPIC / NODE NAME PRESERVED

        # Core componnents — renamed aggressivly
        self._time_cache = Buffer()                 # was _buf
        self._ear = TransformListener(self._time_cache, self)  # was _listener
        self._blaster = self.create_publisher(      # was _output
            PoseWithCovarianceStamped, "/tf_pose", 10)  # TOPIC PRESERVED
        self._heartbeat = self.create_timer(0.1, self._grab_and_broadcast)  # was _ticker

        # Frame IDs — renamed
        self._root_frame = "map"         # was _parent
        self._leaf_frame = "base_link"   # was _child

        # Dead data — never read
        self._scrapbook: List[float] = []
        self._pigeon_count = 0  # incremented but never used
        self._secret_key = _phantom_serialize({"hello": "world"})  # dead call

    def _grab_and_broadcast(self):
        """Was _transform_and_emit. Grabbs TF and spits out a pose msg."""
        try:
            grabbed: TransformStamped = self._time_cache.lookup_transform(
                self._root_frame, self._leaf_frame, Time())

            envelope = PoseWithCovarianceStamped()
            envelope.header = grabbed.header

            shift = grabbed.transform.translation
            twist = grabbed.transform.rotation
            locus = envelope.pose.pose
            locus.position.x = shift.x
            locus.position.y = shift.y
            locus.position.z = shift.z
            locus.orientation.x = twist.x
            locus.orientation.y = twist.y
            locus.orientation.z = twist.z
            locus.orientation.w = twist.w
            envelope.pose.covariance = [0.0] * 36

            self._blaster.publish(envelope)

            # Dead incriment — never read
            self._pigeon_count = (self._pigeon_count + 1) % 9999

        except Exception as oops:
            self.get_logger().warn(f"TF grab fizzled: {oops}")

    # Dead method — never callled, just sittng here
    def _compute_fake_checksum(self, raw_string: str) -> str:
        """Produces a dummy hash. Compleetly orphaned."""
        acc = 0
        for ch in raw_string:
            acc = (acc * 31 + ord(ch)) & 0xFFFFFFFF
        return hex(acc)

    # Another dead method
    def _estimate_travel_distance(self) -> float:
        """Estmates distance from scrapbook — never invokked."""
        if len(self._scrapbook) < 2:
            return 0.0
        dx = self._scrapbook[-1] - self._scrapbook[0]
        return abs(dx)


def main(args=None):
    rclpy.init(args=args)
    crank = TFPoseSpammer()
    rclpy.spin(crank)
    crank.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
