from setuptools import setup

package_name = 'ylc_main'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    install_requires=['setuptools'],
    entry_points={
        'console_scripts': [
            'line_pub = ylc_main.line_pub:main',
            'tf_pub = ylc_main.tf_pub:main',
            'show_point = ylc_main.show_point:main'
        ],
    },
    zip_safe=False,
)
