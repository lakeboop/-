import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time', default='False')

    return LaunchDescription([

        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation (Gazebo) clock if true'),

        Node(
            package='slam_gmapping',
            executable='slam_gmapping',
            name='slam_gmapping',
            output='screen',
            parameters=[{
                'use_sim_time': use_sim_time,
            }],
            remappings=[
                ('scan', '/scan'),
                ('odom', '/odom_combined')
            ]
        ),

        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='initial_map_to_odom',
            arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom_combined'],
            parameters=[{'use_sim_time': False}],
        ),

        Node(
            package='ylc_main',
            executable='tf_pub.py',
            name='tf_pub',
            output='screen',
        )
    ])
