import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node


def generate_launch_description():

    pkg_name = 'ylc_main'
    dwa_dir = get_package_share_directory(pkg_name)
    nav2_bringup_dir = get_package_share_directory('nav2_bringup')

    namespace = LaunchConfiguration('namespace', default='')
    map_path = LaunchConfiguration('map')
    use_sim_time = LaunchConfiguration('use_sim_time')
    params_file = os.path.join(dwa_dir, 'config', 'amcl.yaml')

    declare_namespace_arg = DeclareLaunchArgument(
        'namespace', default_value='', description='Namespace')

    declare_map_arg = DeclareLaunchArgument(
        'map',
        default_value='/userdata/dev_ws/src/origincar/ylc_nav/maps/map1.yaml',
        description='Map path')

    declare_use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time', default_value='false', description='Use sim time')

    declare_slam_mode_arg = DeclareLaunchArgument(
        'slam_mode', default_value='False',
        description='True=SLAM mapping, False=AMCL localization')

    nav2_amcl_localization = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(nav2_bringup_dir, 'launch', 'localization_launch.py')
        ),
        launch_arguments={
            'namespace': namespace,
            'map': map_path,
            'use_sim_time': use_sim_time,
            'params_file': os.path.join(dwa_dir, 'config', 'amcl.yaml'),
            'autostart': 'True',
            'use_composition': 'False',
            'use_respawn': 'False',
            'container_name': 'nav2_container'
        }.items(),
    )

    initial_pose_pub = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='initial_map_to_odom',
        arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom_combined'],
        parameters=[{'use_sim_time': False}],
    )

    tf_pub_node = Node(
        package='ylc_main',
        executable='tf_pub.py',
        name='tf_pub',
        output='screen',
    )

    ld = LaunchDescription()
    ld.add_action(declare_namespace_arg)
    ld.add_action(declare_map_arg)
    ld.add_action(declare_use_sim_time_arg)
    ld.add_action(nav2_amcl_localization)
    ld.add_action(initial_pose_pub)
    ld.add_action(tf_pub_node)

    return ld
