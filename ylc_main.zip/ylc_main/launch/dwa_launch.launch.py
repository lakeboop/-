import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    config_file = os.path.join(
        get_package_share_directory('ylc_main'),
        'config',
        'config.yaml'
    )

    return LaunchDescription([

        Node(
            package="ylc_main",
            executable='line_pub.py',
            name='line_pub',
            output='screen'
        ),

        Node(
            package="ylc_main",
            executable="footprint_publisher",
            name="footprint_publisher",
            parameters=[config_file],
            output='screen',
            arguments=['--ros-args', '--log-level', 'warn'],
        ),

        Node(
            package="ylc_main",
            executable="dwa_planner_node",
            name="DWAPlanner_node",
            parameters=[config_file],
            output='screen',
            arguments=['--ros-args', '--log-level', 'warn'],
        )
    ])
