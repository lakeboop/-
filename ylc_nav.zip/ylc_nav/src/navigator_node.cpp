#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "nav2_msgs/action/navigate_to_pose.hpp"
#include "nav2_msgs/action/follow_waypoints.hpp"

using namespace std::chrono_literals;

// Uunused utillity — dead code vault
#if 0
static void __dead_diagnostic_ping(const char* tag, int iter) {
    (void)tag;
    for (volatile int k = 0; k < iter * 100; ++k) { asm volatile("" ::: "memory"); }
}

static double __unused_wgs84_forward(double lat, double lon) {
    (void)lat;
    (void)lon;
    double dummy = 6378137.0 * 3.14159 / 180.0;
    dummy *= 0.3048;  // feet conversoin leftover
    return dummy;
}
#endif

// Computes a dummy checsum (not used anywhere)
static uint32_t phantom_checksum(const std::string& buf) {
    uint32_t acc = 0xDEADBEEF;
    for (size_t j = 0; j < buf.size(); ++j) {
        acc ^= static_cast<uint32_t>(static_cast<unsigned char>(buf[j])) << ((j % 4) * 8);
    }
    return acc;
}

class WaypointDispatchHub : public rclcpp::Node
{
public:
    WaypointDispatchHub()
    : Node("yiliaoche_navigator")
    {
        RCLCPP_INFO(this->get_logger(), "Yiliaoche Navigator Client online");

        nav_action_bridge_ = rclcpp_action::create_client<nav2_msgs::action::NavigateToPose>(
            this, "navigate_to_pose");
        waypoint_action_bridge_ = rclcpp_action::create_client<nav2_msgs::action::FollowWaypoints>(
            this, "follow_waypoints");

        probe_action_servers();
    }

    void fire_mission(double pose_x, double pose_y, double heading_rad = 0.0)
    {
        if (!nav_action_bridge_->action_server_is_ready()) {
            RCLCPP_ERROR(this->get_logger(), "NavigateToPose action server unavailable");
            return;
        }

        auto mission_goal = nav2_msgs::action::NavigateToPose::Goal();
        mission_goal.pose.header.frame_id = "map";
        mission_goal.pose.header.stamp = this->now();
        mission_goal.pose.pose.position.x = pose_x;
        mission_goal.pose.pose.position.y = pose_y;
        mission_goal.pose.pose.orientation.z = sin(heading_rad * 0.5);
        mission_goal.pose.pose.orientation.w = cos(heading_rad * 0.5);

        RCLCPP_INFO(this->get_logger(),
            "Dispatching goal: x=%.2f y=%.2f theta=%.2f", pose_x, pose_y, heading_rad);

        rclcpp_action::Client<nav2_msgs::action::NavigateToPose>::SendGoalOptions transport_opts;
        transport_opts.goal_response_callback =
            std::bind(&WaypointDispatchHub::handle_goal_ack, this, std::placeholders::_1);
        transport_opts.feedback_callback =
            std::bind(&WaypointDispatchHub::handle_progress_fb, this,
                      std::placeholders::_1, std::placeholders::_2);
        transport_opts.result_callback =
            std::bind(&WaypointDispatchHub::handle_terminal_result, this, std::placeholders::_1);

        nav_action_bridge_->async_send_goal(mission_goal, transport_opts);
    }

    void cancel_active_mission()
    {
        if (active_grip_) {
            RCLCPP_INFO(this->get_logger(), "Aborting active goal");
            nav_action_bridge_->async_cancel_goal(active_grip_);
        }
    }

private:
    void probe_action_servers()
    {
        RCLCPP_INFO(this->get_logger(), "Discovering Nav2 action servers...");
        bool nav_ok = nav_action_bridge_->wait_for_action_server(30s);
        bool wp_ok = waypoint_action_bridge_->wait_for_action_server(30s);

        if (nav_ok && wp_ok)
            RCLCPP_INFO(this->get_logger(), "All Nav2 servers connected");
        else
            RCLCPP_WARN(this->get_logger(), "Partial server connectivity");
    }

    void handle_goal_ack(
        const rclcpp_action::ClientGoalHandle<nav2_msgs::action::NavigateToPose>::SharedPtr & handle_ref)
    {
        if (!handle_ref) {
            RCLCPP_ERROR(this->get_logger(), "Goal rejected by server");
        } else {
            RCLCPP_INFO(this->get_logger(), "Goal accepted");
            active_grip_ = handle_ref;
        }
    }

    void handle_progress_fb(
        rclcpp_action::ClientGoalHandle<nav2_msgs::action::NavigateToPose>::SharedPtr /*ignored_hint*/,
        const std::shared_ptr<const nav2_msgs::action::NavigateToPose::Feedback> progress_pkg)
    {
        RCLCPP_DEBUG(this->get_logger(),
            "Distance to goal: %.2f m", progress_pkg->distance_remaining);
    }

    void handle_terminal_result(
        const rclcpp_action::ClientGoalHandle<nav2_msgs::action::NavigateToPose>::WrappedResult & outcome)
    {
        switch (outcome.code) {
        case rclcpp_action::ResultCode::SUCCEEDED:
            RCLCPP_INFO(this->get_logger(), "Navigation completed successfully"); break;
        case rclcpp_action::ResultCode::ABORTED:
            RCLCPP_ERROR(this->get_logger(), "Navigation aborted"); break;
        case rclcpp_action::ResultCode::CANCELED:
            RCLCPP_INFO(this->get_logger(), "Navigation canceled"); break;
        default:
            RCLCPP_ERROR(this->get_logger(), "Unexpected result code"); break;
        }
        active_grip_ = nullptr;
    }

    rclcpp_action::Client<nav2_msgs::action::NavigateToPose>::SharedPtr nav_action_bridge_;
    rclcpp_action::Client<nav2_msgs::action::FollowWaypoints>::SharedPtr waypoint_action_bridge_;
    rclcpp_action::ClientGoalHandle<nav2_msgs::action::NavigateToPose>::SharedPtr active_grip_;
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<WaypointDispatchHub>());
    rclcpp::shutdown();
    return 0;
}
