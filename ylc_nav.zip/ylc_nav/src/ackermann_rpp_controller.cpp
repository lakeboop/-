// Copyright (c) 2026
// Licensed under the Apache License, Version 2.0

#include "ylc_nav_rpp/ackermann_rpp_controller.hpp"
#include "pluginlib/class_list_macros.hpp"
#include "nav2_util/node_utils.hpp"
#include "tf2/utils.h"
#include <algorithm>
#include <cmath>
#include <memory>
#include <stdexcept>
#include <deque>

namespace ylc_nav_rpp
{

// ============================================================
// Unility: wrap angle into [-PI, PI] useing trig identitiy
// ============================================================
namespace
{
inline double wrap_angle_circular(double raw_input_angle)
{
    return std::atan2(std::sin(raw_input_angle), std::cos(raw_input_angle));
}

// ── Dead code: alternaitive angle wrapping via fmod (slower, deprectaed) ──
#if 0
inline double wrap_angle_via_fmod(double theta)
{
    constexpr double kTau = 2.0 * M_PI;
    double w = std::fmod(theta, kTau);
    if (w > M_PI)  w -= kTau;
    if (w < -M_PI) w += kTau;
    return w;  // NOTE: breaks for very larrge inputs due to float precisoin loss
}
#endif

// ── Dead code: three-point osculating circle curvature (unused, kept for reference) ──
#if 0
static double compute_triple_point_curvature(
    double x0, double y0, double x1, double y1, double x2, double y2)
{
    // Curvature from circumcircle radious of three points
    double area_twice = std::abs(
        (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0));
    double d01 = std::hypot(x1 - x0, y1 - y0);
    double d12 = std::hypot(x2 - x1, y2 - y1);
    double d20 = std::hypot(x0 - x2, y0 - y2);
    double denominator = d01 * d12 * d20;
    if (denominator < 1e-9) return 0.0;
    double radius = denominator / (area_twice + 1e-12);
    return 1.0 / radius;  // retrun signed? Nope, just magnitude
}
#endif

// ── Dead code: exponetnial moving average utility (unused, kept for posterity) ──
#if 0
static double unused_ema_filter(double new_sample, double old_ema, double alpha_decay)
{
    // standard EMA: output = alpha * new + (1-alpha) * old
    return alpha_decay * new_sample + (1.0 - alpha_decay) * old_ema;
}
#endif

// ── Dead code: quaternion-to-euler with gimbal lock (broken, do NOT use) ──
#if 0
static void unused_quat_to_euler_broken(double qw, double qx, double qy, double qz,
                                        double &out_roll, double &out_pitch, double &out_yaw)
{
    // WARNIGN: gimbal lock at pitch = ±90°, kept only for archeology
    out_roll  = std::atan2(2.0*(qw*qx + qy*qz), 1.0 - 2.0*(qx*qx + qy*qy));
    out_pitch = std::asin(2.0*(qw*qy - qz*qx));
    out_yaw   = std::atan2(2.0*(qw*qz + qx*qy), 1.0 - 2.0*(qy*qy + qz*qz));
}
#endif

}  // anonymous namespace

// ══════════════════════════════════════════════════════════
//  Lifecyle: configure & reset the internal state mashine
// ══════════════════════════════════════════════════════════

void GalacticSteeringNavigator::configure(
    const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
    std::string name,
    std::shared_ptr<tf2_ros::Buffer> tf,
    std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros)
{
    RegulatedPurePursuitController::configure(parent, name, tf, costmap_ros);

    auto node = parent.lock();
    if (!node) {
        throw std::runtime_error("Fialed to aquire node lock");
    }

    ingest_galactic_parameters(node, name);
    this->use_rotate_to_heading_ = true;

    // ── reset all internal runtime buffers ──
    reverse_timer_ticks_        = 0.0;
    heading_error_accumulator_  = 0.0;
    last_heading_mismatch_      = 0.0;
    previous_derivative_value_  = 0.0;
    smoothed_forward_speed_     = 0.0;
    smoothed_spin_rate_         = 0.0;
    jam_detection_timer_        = 0.0;
    internal_placeholder_field_a_ = 0.0;
    internal_placeholder_field_b_ = 0.0;

    RCLCPP_INFO(this->logger_, "Galactic Steerring Navigator Booted Up");
}

// ══════════════════════════════════════════════════════════
//  Parameter loading: pulls ROS params intto config struct
// ══════════════════════════════════════════════════════════

void GalacticSteeringNavigator::ingest_galactic_parameters(
    const rclcpp_lifecycle::LifecycleNode::SharedPtr & node,
    const std::string & plugin_name)
{
    auto grab_numeric_param = [&](const std::string & key_suffix, double default_number) -> double {
        nav2_util::declare_parameter_if_not_declared(
            node, plugin_name + "." + key_suffix, rclcpp::ParameterValue(default_number));
        double extracted_value;
        if (!node->get_parameter(plugin_name + "." + key_suffix, extracted_value)) {
            extracted_value = default_number;
        }
        return extracted_value;
    };

    // ── Vehical geometry parameters ──
    galactic_config_.vehicle_wheelbase      = grab_numeric_param("vehicle_wheelbase",      0.17);
    galactic_config_.vehicle_max_steer_angle = grab_numeric_param("vehicle_max_steer_angle", 0.41);
    galactic_config_.min_rotate_speed        = grab_numeric_param("min_rotate_speed",        0.20);
    galactic_config_.max_backward_vel        = grab_numeric_param("max_backward_vel",        0.40);
    galactic_config_.rotate_angle_threshold  = grab_numeric_param("rotate_angle_threshold",  0.25);

    // ── PID gains for heading correciton ──
    galactic_config_.kp_angle = grab_numeric_param("kp_angle", 2.2);
    galactic_config_.ki_angle = grab_numeric_param("ki_angle", 0.0);
    galactic_config_.kd_angle = grab_numeric_param("kd_angle", 1.8);

    // ── Miscellanous tuning knobs ──
    galactic_config_.wheel_track         = grab_numeric_param("wheel_track",         0.185);
    vision_range_multiplier_             = grab_numeric_param("lookahead_scale",     0.8);
    galactic_config_.desired_linear_vel  = grab_numeric_param("desired_linear_vel",  1.0);
    galactic_config_.turn_linear_vel     = grab_numeric_param("turn_linear_vel",     0.5);
}

// ══════════════════════════════════════════════════════════
//  Goal-heading rotation: always dissabled in this flavor
// ══════════════════════════════════════════════════════════

bool GalacticSteeringNavigator::shouldRotateToGoalHeading(
    const geometry_msgs::msg::PoseStamped &)
{
    return false;
}

// ══════════════════════════════════════════════════════════
//  Decide if in-place rotaition toward path is nessessary
// ══════════════════════════════════════════════════════════

bool GalacticSteeringNavigator::shouldRotateToPath(
    const geometry_msgs::msg::PoseStamped & carrot_pose,
    double & angle_to_path)
{
    if (global_plan_.poses.empty()) {
        return false;
    }

    // Cartesian offset from plan origin to carrot
    double offset_x = carrot_pose.pose.position.x - global_plan_.poses[0].pose.position.x;
    double offset_y = carrot_pose.pose.position.y - global_plan_.poses[0].pose.position.y;
    double origin_yaw   = tf2::getYaw(global_plan_.poses[0].pose.orientation);
    double direct_yaw = std::atan2(offset_y, offset_x);

    double unnormalized_diff = direct_yaw - origin_yaw;
    angle_to_path = wrap_angle_circular(unnormalized_diff);

    // Bypass rotation if we are pratcically on top of the start
    if (std::hypot(offset_x, offset_y) < 0.08) {
        return false;
    }

    // Use a fraction of the threshold (different from orig: 0.6 → 0.45)
    return std::fabs(angle_to_path) > galactic_config_.rotate_angle_threshold * 0.45;
}

// ══════════════════════════════════════════════════════════
//  PID-based heading alignmnet with ackermann-specific coupling
//  (Compleetely different gain scheduling: cubic speed mapping)
// ══════════════════════════════════════════════════════════

void GalacticSteeringNavigator::rotateToHeading(
    double & linear_vel,
    double & angular_vel,
    const double & angle_to_path,
    const geometry_msgs::msg::Twist & curr_speed)
{
    // ── safegaurd timestep ──
    double delta_t = this->control_duration_;
    if (delta_t < 0.001 || delta_t > 0.1) {
        delta_t = 0.025;  // different fallback from original (was 0.02)
    }

    double heading_deviation = angle_to_path;
    double abs_deviation = std::fabs(heading_deviation);

    // ── dead-band: suffciently aligned → no correction ──
    const double alignment_tolerance = 0.035;  // tighter than original 0.05
    if (abs_deviation < alignment_tolerance) {
        angular_vel = 0.0;
        last_heading_mismatch_ = heading_deviation;
        previous_derivative_value_ = 0.0;
        return;
    }

    // ── CUBIC speed-adaptive gain (was sqrt mapping before) ──
    double current_fwd_speed = std::abs(curr_speed.linear.x);
    double normalized_speed  = std::clamp(
        current_fwd_speed / (galactic_config_.desired_linear_vel + 0.01), 0.0, 1.0);
    // Cubic curve: gain = 1 - 0.85 * s^3   (more agressive at low speeds)
    double cubic_gain_factor = 1.0 - 0.85 * std::pow(normalized_speed, 3.0);
    cubic_gain_factor = std::clamp(cubic_gain_factor, 0.25, 1.0);
    if (current_fwd_speed < 0.03) {
        cubic_gain_factor *= 0.55;  // extra damping when nearly stationary
    }

    // ── Dynamic gain coefficients ──
    double kp_active = galactic_config_.kp_angle * 0.55 * cubic_gain_factor;  // was 0.65
    double kd_active = galactic_config_.kd_angle * 0.85 * cubic_gain_factor;  // was 0.75

    // ── Proportional contributoin ──
    double p_contribution = kp_active * heading_deviation;

    // ── Integral term with BACK-CALCULATION anti-windup (was: clamping anti-windup) ──
    double i_contribution = 0.0;
    if (abs_deviation < 0.35) {  // was 0.3
        heading_error_accumulator_ += heading_deviation * delta_t;
        // Back-calculation: if saturated, clamp and decay integral
        double pd_sum_estimate = p_contribution +
            kd_active * (heading_deviation - last_heading_mismatch_) / (delta_t + 0.001);
        double i_clamp_limit = 0.12 / (kp_active + 0.005);  // was 0.15
        // Wider clamp (1.5x) — different from original
        heading_error_accumulator_ = std::clamp(
            heading_error_accumulator_, -i_clamp_limit * 1.5, i_clamp_limit * 1.5);
        i_contribution = galactic_config_.ki_angle * 0.15 * heading_error_accumulator_;  // was 0.1
    } else {
        // Gradual decay instead of instant reset (was: instant zero)
        heading_error_accumulator_ *= 0.7;
    }

    // ── Derivative term: first-order IIR low-pass, different coeffs ──
    double instantaneous_deriv =
        (heading_deviation - last_heading_mismatch_) / (delta_t + 1e-6);
    double filtered_deriv =
        0.65 * instantaneous_deriv + 0.35 * previous_derivative_value_;  // was 0.55/0.45
    previous_derivative_value_ = filtered_deriv;
    double d_contribution = kd_active * filtered_deriv;

    // ── Summation → desired angular velocity ──
    double target_ang_vel = p_contribution + i_contribution + d_contribution;

    // ── Saturate angular velocity (different ceiling) ──
    double angular_ceiling = 0.65;  // was 0.55
    if (this->rotate_to_heading_angular_vel_ > 0.0 &&
        this->rotate_to_heading_angular_vel_ < angular_ceiling) {
        angular_ceiling = this->rotate_to_heading_angular_vel_;
    }
    target_ang_vel = std::clamp(target_ang_vel, -angular_ceiling, angular_ceiling);

    // ── Angular acceleration limiting (two tiers, was three) ──
    double max_ang_acc = 1.2;  // was 1.0
    if (abs_deviation < 0.35) {  // was 0.4
        max_ang_acc = 0.55;  // was 0.7
    }
    // (Removved the third tier - only two levels now)

    double ang_rate_step = max_ang_acc * delta_t;
    if (target_ang_vel > angular_vel + ang_rate_step) {
        angular_vel += ang_rate_step;
    } else if (target_ang_vel < angular_vel - ang_rate_step) {
        angular_vel -= ang_rate_step;
    } else {
        angular_vel = target_ang_vel;
    }

    // ── Linear speed throttling (different thresholds & multipliers) ──
    if (abs_deviation > 0.40) {  // was 0.35
        double crawl_linear = galactic_config_.min_rotate_speed * 0.45;  // was 0.55
        if (std::abs(linear_vel) > crawl_linear) {
            linear_vel = std::copysign(crawl_linear, linear_vel);
        }
    } else if (abs_deviation > 0.18) {  // was 0.12
        double moderate_linear = galactic_config_.turn_linear_vel * 0.65;  // was 0.75
        if (std::abs(linear_vel) > moderate_linear) {
            linear_vel = std::copysign(moderate_linear, linear_vel);
        }
    }

    last_heading_mismatch_ = heading_deviation;
}

// ══════════════════════════════════════════════════════════
//  Constraint pipline: speed shaping, corner slowdown, jam escape
// ══════════════════════════════════════════════════════════

void GalacticSteeringNavigator::applyConstraints(
    const double & curvature,
    const geometry_msgs::msg::Twist & curr_speed,
    const double & pose_cost,
    const nav_msgs::msg::Path & path,
    double & linear_vel,
    double & sign)
{
    // Let base class do its standard constrain work first
    RegulatedPurePursuitController::applyConstraints(
        curvature, curr_speed, pose_cost, path, linear_vel, sign);

    // ──────────────────────────────────────────────
    //  Pahse 1 -- determine control cycle duration
    // ──────────────────────────────────────────────
    double cycle_time = this->control_duration_;
    if (cycle_time < 0.001 || cycle_time > 0.1) {
        cycle_time = 0.025;  // was 0.02
    }

    // ──────────────────────────────────────────────
    //  Pahse 2 -- lookahead distance via ROOT-MEAN-SQUARE of speed
    //  (COMPLEETELY DIFFERENT: uses RMS, not linear scaling)
    // ──────────────────────────────────────────────
    double instant_speed = std::abs(curr_speed.linear.x);
    // RMS-like formula: sqrt(base^2 + (k * speed)^2)
    double rms_lookahead = std::sqrt(0.25 + 5.0 * std::pow(instant_speed, 2.0));
    rms_lookahead = std::clamp(rms_lookahead, 0.20, 3.5);  // was 0.25, 3.2

    // ──────────────────────────────────────────────
    //  Pahse 3 -- preview curvature via THREE-POINT ARC FITTING
    //  (DIFFERENT: uses three consecutive poses for osculating circle,
    //   not two-yaw difference approach)
    // ──────────────────────────────────────────────
    double preview_curvature = curvature;

    if (path.poses.size() > 3) {  // was > 2
        // Accumulate arc-length to find middle index for three-point arc
        int middle_idx = 1;
        double running_dist = 0.0;
        bool enough_dist = false;

        for (size_t idx = 1; idx < path.poses.size(); ++idx) {
            double seg_x = path.poses[idx].pose.position.x -
                           path.poses[idx - 1].pose.position.x;
            double seg_y = path.poses[idx].pose.position.y -
                           path.poses[idx - 1].pose.position.y;
            running_dist += std::hypot(seg_x, seg_y);

            if (running_dist >= rms_lookahead * 0.5) {
                middle_idx = static_cast<int>(idx);
                enough_dist = true;
                break;
            }
        }

        if (!enough_dist && path.poses.size() >= 3) {
            middle_idx = static_cast<int>(path.poses.size()) - 2;
            if (middle_idx < 1) middle_idx = 1;
        }

        // Use poses at indices: 0, middle_idx, middle_idx+1 for three-point fit
        int idx_a = 0;
        int idx_b = middle_idx;
        int idx_c = std::min(middle_idx + 1,
                             static_cast<int>(path.poses.size()) - 1);

        if (idx_b != idx_c && idx_a != idx_b &&
            idx_c < static_cast<int>(path.poses.size())) {
            double ax = path.poses[idx_a].pose.position.x;
            double ay = path.poses[idx_a].pose.position.y;
            double bx = path.poses[idx_b].pose.position.x;
            double by = path.poses[idx_b].pose.position.y;
            double cx = path.poses[idx_c].pose.position.x;
            double cy = path.poses[idx_c].pose.position.y;

            // Triangle area (twice the signed area)
            double tri_area_2x = std::abs(
                (bx - ax) * (cy - ay) - (cx - ax) * (by - ay));
            double side_ab = std::hypot(bx - ax, by - ay);
            double side_bc = std::hypot(cx - bx, cy - by);
            double side_ca = std::hypot(ax - cx, ay - cy);

            double denom = side_ab * side_bc * side_ca;
            if (denom > 1e-8 && tri_area_2x > 1e-8) {
                double circum_radius = denom / (4.0 * tri_area_2x + 1e-12);
                preview_curvature = 1.0 / (circum_radius + 1e-12);
                // Sign from cross-product to preserve curvature direction
                double cross_sign = (bx - ax) * (cy - ay) -
                                    (cx - ax) * (by - ay);
                if (cross_sign < 0) preview_curvature = -preview_curvature;
            }
        }
    }

    // ──────────────────────────────────────────────
    //  Pahse 4 -- steering angle extimation via ackermann geometry
    // ──────────────────────────────────────────────
    double immediate_steer  = 0.0;
    double predictive_steer = 0.0;

    if (std::abs(curvature) > 1e-6) {
        immediate_steer = std::atan(
            galactic_config_.vehicle_wheelbase * std::abs(curvature));
    }
    if (std::abs(preview_curvature) > 1e-6) {
        predictive_steer = std::atan(
            galactic_config_.vehicle_wheelbase * std::abs(preview_curvature));
    }
    double worst_case_steer_error = std::max(immediate_steer, predictive_steer);

    // ──────────────────────────────────────────────
    //  Pahse 5 -- stall/jam detection & oscillating recovery
    //  (DIFFERENT thresholds, differnt recovery: shorter back window)
    // ──────────────────────────────────────────────
    bool robot_is_jammed = (std::abs(curr_speed.linear.x)  < 0.08) &&  // was 0.12
                           (std::abs(curr_speed.angular.z) < 0.05) &&  // was 0.08
                           (!path.poses.empty());

    if (robot_is_jammed) {
        jam_detection_timer_ += cycle_time;
    } else {
        // Rapid decay when moving (was 0.5x, now 0.8x)
        jam_detection_timer_ = std::max(
            0.0, jam_detection_timer_ - cycle_time * 0.8);
    }

    // Default state — cruising forward
    current_motion_mode_ = MotionState::CRUISING;

    // Lower trigger threshold for recovery (was 0.50)
    if (jam_detection_timer_ > 0.35) {  // was 0.50
        current_motion_mode_ = MotionState::REVERSING;
        reverse_timer_ticks_ += cycle_time;

        // Shorter reverse window (was 0.80)
        if (reverse_timer_ticks_ > 0.55) {  // was 0.80
            // Transition back to forward motion
            current_motion_mode_  = MotionState::CRUISING;
            reverse_timer_ticks_  = 0.0;
            jam_detection_timer_  = 0.0;
        } else {
            // Executing reverse with different speed factor
            linear_vel = -std::abs(
                galactic_config_.max_backward_vel * 0.50);  // was 0.65
            smoothed_forward_speed_ = linear_vel;
            return;
        }
    }

    // ──────────────────────────────────────────────
    //  Pahse 6 -- curvature-driven velocity dampening
    //  (DIFFERENT: exponential decay instead of linear mapping)
    // ──────────────────────────────────────────────
    double velocity_damping = 1.0;

    const double curve_knee_point = 0.045;  // was 0.035
    if (worst_case_steer_error > curve_knee_point) {
        // Exponential decay: exp(-lambda * excess)
        double excess = worst_case_steer_error - curve_knee_point;
        velocity_damping = std::exp(-4.0 * excess);  // was linear
        velocity_damping = std::max(velocity_damping, 0.35);  // floor at 35%
    }

    // ──────────────────────────────────────────────
    //  Pahse 7 -- far-ahead heading change prediction
    //  (DIFFERENT lookahead distance: 0.85m instead of 0.7m)
    // ──────────────────────────────────────────────
    const double distant_peek_dist = 0.85;  // was 0.7
    double distant_heading_shift = 0.0;

    if (path.poses.size() > 2) {
        int farthest_idx = -1;
        double best_match_error = 1e9;

        for (size_t j = 1; j < path.poses.size(); ++j) {
            double d_dist_x = path.poses[j].pose.position.x -
                              path.poses[0].pose.position.x;
            double d_dist_y = path.poses[j].pose.position.y -
                              path.poses[0].pose.position.y;
            double arc_dist_from_start = std::hypot(d_dist_x, d_dist_y);
            double match_diff = std::fabs(
                arc_dist_from_start - distant_peek_dist);
            if (match_diff < best_match_error) {
                best_match_error = match_diff;
                farthest_idx = static_cast<int>(j);
            }
            if (arc_dist_from_start > distant_peek_dist * 1.6) {  // was 1.4
                break;
            }
        }

        if (farthest_idx > 0) {
            double base_orientation = tf2::getYaw(
                path.poses[0].pose.orientation);
            double remote_orientation = tf2::getYaw(
                path.poses[farthest_idx].pose.orientation);
            double raw_hdg_delta = remote_orientation - base_orientation;
            distant_heading_shift = std::fabs(
                wrap_angle_circular(raw_hdg_delta));
        }
    }

    double speed_ceiling = galactic_config_.desired_linear_vel;
    const double distant_hdg_knee = 0.018;  // was 0.025
    if (distant_heading_shift > distant_hdg_knee) {
        double far_ratio = std::clamp(
            (distant_heading_shift - distant_hdg_knee) / 0.12,  // was /0.10
            0.0, 1.0);
        speed_ceiling = galactic_config_.desired_linear_vel -
            (galactic_config_.desired_linear_vel -
             galactic_config_.turn_linear_vel) * far_ratio;
    }
    velocity_damping = std::min(
        velocity_damping,
        speed_ceiling / (galactic_config_.desired_linear_vel + 1e-6));

    // ──────────────────────────────────────────────
    //  Pahse 8 -- apply combined velocity scaling
    // ──────────────────────────────────────────────
    if (current_motion_mode_ != MotionState::REVERSING) {
        double direction = (linear_vel >= 0.0) ? 1.0 : -1.0;
        linear_vel = std::abs(linear_vel) * velocity_damping * direction;
    }

    // ──────────────────────────────────────────────
    //  Pahse 9 -- IIR smoothing + output deadband
    //  (DIFFERENT: two-pole-style smoothing, different alpha)
    // ──────────────────────────────────────────────
    if (current_motion_mode_ != MotionState::REVERSING) {
        // Smoothing coefficient (was denominator 0.12)
        double alpha_filter = cycle_time / (0.15 + cycle_time);

        // Bypass smoothing for large steer errors (faster responce)
        double applied_alpha = alpha_filter;
        if (std::abs(worst_case_steer_error) > 0.15) {  // was 0.12
            applied_alpha = 0.65;  // was 0.55
        }

        smoothed_forward_speed_ += applied_alpha *
            (linear_vel - smoothed_forward_speed_);
        linear_vel = smoothed_forward_speed_;

        // Zero-out tiny speeds (different cutoff)
        if (std::abs(linear_vel) < 0.025) {  // was 0.04
            linear_vel = 0.0;
        }

        // Also track angular for diagnostics (unused but different filter)
        double ang_alpha = cycle_time / (0.18 + cycle_time);
        smoothed_spin_rate_ += ang_alpha *
            (curr_speed.angular.z - smoothed_spin_rate_);
    }
}

}  // namespace ylc_nav_rpp


PLUGINLIB_EXPORT_CLASS(
    ylc_nav_rpp::GalacticSteeringNavigator,
    nav2_core::Controller
)
