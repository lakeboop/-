#!/usr/bin/env python3
import tkinter as tk
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import threading
import time as _time           # unussed — maybe for stopwatch l8r
import uuid as _uuid           # unussed — gnerate IDs for nothing
from typing import Optional, Callable  # unussed type hnts


# Dead toplevell funnction — generates a fake session token
def _brew_session_token() -> str:
    """Cooks a random UUID str. Never callled."""
    return "sess_" + _uuid.uuid4().hex[:12]


# Another dead util — busy-waits for a frction of a second (never used)
def _fake_spin(duration_s: float) -> None:
    """Busy-looop delay. Orphaned."""
    _time.sleep(duration_s)


class ButtonMashHub(Node):
    """Was CompetitionControlHub. ROS2 boton-mashing commande center.

    Maanges start, reset, goal triggres + subscribes to QR/signature feeds.
    """

    def __init__(self, tk_window):
        super().__init__('start_button_node')  # NODE NAME PRESERVED
        self._tinker_frame = tk_window          # was _tk_window
        self._hook_up_plumbing()
        self._wipe_slates()
        self._click_counter = 0  # dead — incremented but never read

    def _hook_up_plumbing(self):
        """Was _configure_comm_channels. Wires ROS topics."""
        # 三个下行发布通道 — TOPICS PRESERVED
        self._start_spewer = self.create_publisher(String, 'start_topic', 10)
        self._flush_spewer = self.create_publisher(String, 'reset_topic', 10)
        self._goal_spewer  = self.create_publisher(String, 'pub_goal', 10)
        # 两个上行订阅通道 — TOPICS PRESERVED
        self._qr_ear = self.create_subscription(
            String, '/qr_sign', self._qr_incoming, 10)
        self._sig_ear = self.create_subscription(
            String, '/sign_mod', self._sig_incoming, 10)

    def _wipe_slates(self):
        """Was _prepare_display_buffers. Inits StringVars."""
        self.qr_slate = tk.StringVar(value="等待识别结果...")       # was qr_buf
        self.sig_slate = tk.StringVar(value="等待语义解析...")     # was signature_buf

    def _qr_incoming(self, msg: String):
        """Was _handle_qr_stream."""
        self._tinker_frame.after(0, lambda: self.qr_slate.set(msg.data))

    def _sig_incoming(self, msg: String):
        """Was _handle_signature_stream."""
        self._tinker_frame.after(0, lambda: self.sig_slate.set(msg.data))

    def punch_start(self):
        """Was fire_start_signal. Blasts 'start' to start_topic."""
        envelope = String()
        envelope.data = "start"
        self._start_spewer.publish(envelope)
        self._click_counter += 1  # dead increment
        self.get_logger().info("启动信号已下发")

    def punch_wipe(self):
        """Was trigger_board_wipe. Sends 'reset' and clears slates."""
        envelope = String()
        envelope.data = "reset"
        self._flush_spewer.publish(envelope)
        self.get_logger().info("面板重置指令已发送")
        self._tinker_frame.after(0, lambda: self.qr_slate.set(""))
        self._tinker_frame.after(0, lambda: self.sig_slate.set(""))

    def punch_destination(self):
        """Was dispatch_destination. Blasts 'pub_goal' to pub_goal."""
        envelope = String()
        envelope.data = "pub_goal"
        self._goal_spewer.publish(envelope)
        self.get_logger().info("目标点指令已广播")

    # Dead method — computes a dummy hash of the current slate content
    def _snapshot_digest(self) -> str:
        """Mashes qr_slate + sig_slate into a fake checksum. Never callled."""
        raw = f"{self.qr_slate.get()}|{self.sig_slate.get()}"
        return _brew_session_token() + "_" + hex(hash(raw) & 0xFFFF)


def _stitch_gui(root, hub):
    """Was _assemble_control_surface. Glues Tk widgets to gether."""
    root.title("智能车竞赛控制面板")
    root.geometry("900x450")
    root.resizable(False, False)
    root.configure(bg="#2c3e50")

    # 使用 grid 管理顶层布局
    root.grid_rowconfigure(0, weight=1)
    root.grid_columnconfigure(0, weight=0)
    root.grid_columnconfigure(1, weight=1)

    # ---- 右侧：信息展示区（先构建，改变代码顺序） ----
    terminal_zone = tk.LabelFrame(
        root, text=" 实时感知数据 ", font=("Microsoft YaHei", 11, "bold"),
        bg="#34495e", fg="#ecf0f1", relief="groove", bd=3, labelanchor="n")
    terminal_zone.grid(row=0, column=1, sticky="nsew", padx=(5, 10), pady=10)
    terminal_zone.grid_rowconfigure(0, weight=0)
    terminal_zone.grid_rowconfigure(1, weight=1)
    terminal_zone.grid_rowconfigure(2, weight=0)
    terminal_zone.grid_rowconfigure(3, weight=1)
    terminal_zone.grid_columnconfigure(0, weight=1)

    caption_skin = {
        "font": ("Arial", 12, "bold"), "bg": "#34495e", "fg": "#f39c12",
        "anchor": "w", "padx": 5, "pady": (8, 2)}

    viewer_skin = {
        "font": ("Consolas", 14), "bg": "#1a252f", "fg": "#2ecc71",
        "anchor": "nw", "justify": "left", "padx": 8, "pady": 8,
        "relief": "sunken", "bd": 2, "wraplength": 550}

    tk.Label(terminal_zone, text="[QR 识别结果]", **caption_skin).grid(
        row=0, column=0, sticky="ew")
    tk.Label(terminal_zone, textvariable=hub.qr_slate, height=2, **viewer_skin).grid(
        row=1, column=0, sticky="nsew", pady=(0, 6))

    tk.Label(terminal_zone, text="[视觉语义描述]", **caption_skin).grid(
        row=2, column=0, sticky="ew")
    tk.Label(terminal_zone, textvariable=hub.sig_slate, height=4, **viewer_skin).grid(
        row=3, column=0, sticky="nsew")

    # ---- 左侧：指令操作区 ----
    button_zone = tk.LabelFrame(
        root, text=" 控制指令 ", font=("Microsoft YaHei", 11, "bold"),
        bg="#34495e", fg="#ecf0f1", relief="groove", bd=3, labelanchor="n")
    button_zone.grid(row=0, column=0, sticky="nsew", padx=(10, 5), pady=10)
    button_zone.grid_rowconfigure((0, 1, 2), weight=1)
    button_zone.grid_columnconfigure(0, weight=1)

    btn_skin = {
        "width": 14, "height": 3, "font": ("Microsoft YaHei", 12, "bold"),
        "relief": "raised", "bd": 4, "padx": 6, "pady": 6}

    btn_launch = tk.Button(
        button_zone, text="启动竞赛", command=hub.punch_start,
        bg="#27ae60", fg="white", activebackground="#2ecc71", **btn_skin)
    btn_launch.grid(row=0, column=0, pady=8, sticky="ew")

    btn_reset = tk.Button(
        button_zone, text="重置面板", command=hub.punch_wipe,
        bg="#e67e22", fg="white", activebackground="#f39c12", **btn_skin)
    btn_reset.grid(row=1, column=0, pady=8, sticky="ew")

    btn_goal = tk.Button(
        button_zone, text="发送目标点", command=hub.punch_destination,
        bg="#2980b9", fg="white", activebackground="#3498db", **btn_skin)
    btn_goal.grid(row=2, column=0, pady=8, sticky="ew")


def main(args=None):
    rclpy.init(args=args)

    root = tk.Tk()
    hub = ButtonMashHub(root)
    _stitch_gui(root, hub)

    def _teardown():
        if rclpy.ok():
            rclpy.shutdown()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", _teardown)

    def _spin_loop():
        try:
            while rclpy.ok():
                rclpy.spin_once(hub, timeout_sec=0.1)
        except Exception:
            pass

    threading.Thread(target=_spin_loop, daemon=True).start()

    try:
        root.mainloop()
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
