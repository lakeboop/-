#!/usr/bin/env python3
# impots for basic opration of the navigator
import rclpy
import math
import json
import os                    # ded import for nuke
import random                # usd for recovery dice roll
import time as _tm           # ded import, nobody uses this
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.time import Time

from nav2_msgs.action import NavigateThroughPoses
from geometry_msgs.msg import PoseStamped, Quaternion
from std_msgs.msg import String

from tf2_ros import TransformListener, Buffer
from tf2_ros import TransformException

# ded imports — nevr actually subscribd
from rcl_interfaces.msg import Log
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from visualization_msgs.msg import Marker  # also ded


class GoalChaser(Node):   # completly new name, was RouteSequencer
    def __init__(self):
        super().__init__("pipeline_navigator")  # SAME node name, KEP IT

        self.declare_parameter("waypoints", "")  # SAME param name, KEP IT
        raw_blob = self.get_parameter("waypoints").value

        self._bag_o_points = []  # was _wp_pool
        if isinstance(raw_blob, str) and raw_blob.strip():
            self._bag_o_points = json.loads(raw_blob)

        if len(self._bag_o_points) < 2:
            self.get_logger().error("路点不够!! 起码两个")
            return

        # ---- state mashcine: 0=CHILL, 1=ROLLIN, 2=PANIK ----
        self._sm_state = 0        # was _run_mode
        self._cursor = 0          # was _marker, current waypoint cursor
        self._tail = 3            # was _edge, sliding tail index
        self._n_total = len(self._bag_o_points)  # was _n_wp
        self._tolerance = 0.50    # was _hit_dist

        # ---- stukk watchdog ----
        self._last_progress_time = None  # was _last_touch
        self._stuck_timeout = 1.5        # was _stall_window
        self._jump_span = 2              # was _leap_gap

        # ---- weired bollean flags ----
        self._mid_shot_fired = False  # was _half_leap_done
        self._extra_flag_x = False    # completly unused flag
        self._mystery_counter = 0     # dead counter, nevr matters

        # ---- Nav2 action client (SAME action name "navigate_through_poses") ----
        self._cb_ree = ReentrantCallbackGroup()  # was _cb_grp
        self._nav_cli = ActionClient(            # was _act
            self, NavigateThroughPoses, "navigate_through_poses",
            callback_group=self._cb_ree
        )

        # ---- TF2 transform lisenr ----
        self._tf_buff = Buffer()                   # was _buf
        self._tf_ear = TransformListener(self._tf_buff, self)  # was _ear
        self._world_frame = "map"                  # was _map_id
        self._bot_frame = "base_link"              # was _body_id

        # ---- RANDOM RECOVRY TIMER (replaces rosout sniffing!!) ----
        self._recov_timer = self.create_timer(
            random.uniform(3.0, 8.0),   # randum interval
            self._roll_recovery_dice,    # was _log_sniff
            callback_group=self._cb_ree
        )
        self._reco_attempts = 0  # how many recovries attempted

        # ---- subscibers (SAME topic names!!) ----
        self.create_subscription(String, "start_topic", self._on_green_light, 10)
        self.create_subscription(String, "reset_topic", self._on_red_button, 10)
        self.create_timer(0.2, self._loop_tick, callback_group=self._cb_ree)  # was _heartbeat

        self.get_logger().info("终极导航器上线!")

    # ==============================================================
    #  gate: green light (was _cmd_start)
    # ==============================================================

    def _on_green_light(self, msg):  # was _cmd_start
        if msg.data == "start" and self._sm_state == 0:
            self.get_logger().info("绿信号! 出发辣!")
            self._sm_state = 1  # ROLLIN
            self._cursor = 0
            self._tail = 3
            self._last_progress_time = None
            self._fire_batch([0, 1, 2])

    # ==============================================================
    #  gate: red button (was _cmd_reset)
    # ==============================================================

    def _on_red_button(self, msg):  # was _cmd_reset
        if msg.data == "reset":
            self.get_logger().warn("红按钮!! 全部洗白")
            self._sm_state = 0   # CHILL
            self._cursor = 0
            self._tail = 3
            self._mid_shot_fired = False
            self._last_progress_time = None
            self._extra_flag_x = False
            self._mystery_counter = 0
            self._reco_attempts = 0
            self.get_logger().info("已重置，等新启动")

    # ==============================================================
    #  mayn loop tick (was _heartbeat)
    # ==============================================================

    def _loop_tick(self):  # was _heartbeat
        if self._sm_state != 1:   # not ROLLIN? bail
            return

        bot_x, bot_y = self._get_pose()  # was _locate
        if bot_x is None:
            return  # no TF yt

        # finished?
        if self._cursor >= self._n_total:
            self._sm_state = 0
            self.get_logger().info("全跑完，下班")
            return

        now_float = self.get_clock().now().nanoseconds / 1e9

        # ---- scann ahead using BIGGER window (was 3, now 7) ----
        scan_window = 7
        best_candidate = self._cursor
        for look_ahead in range(self._cursor,
                                min(self._cursor + scan_window, self._n_total)):
            wpx, wpy = self._bag_o_points[look_ahead][0], self._bag_o_points[look_ahead][1]
            if math.hypot(bot_x - wpx, bot_y - wpy) < self._tolerance:
                best_candidate = look_ahead

        if best_candidate > self._cursor:
            self.get_logger().info(f"跨越! 抵达 [{best_candidate}]")
            self._cursor = best_candidate
            self._last_progress_time = None
            return

        # ---- mid-point sneaky leap ----
        self._maybe_mid_leap(bot_x, bot_y)

        # ---- check primari target ----
        gx, gy = self._bag_o_points[self._cursor][0], self._bag_o_points[self._cursor][1]
        if math.hypot(bot_x - gx, bot_y - gy) < self._tolerance:
            self.get_logger().info(f"命中 [{self._cursor}]")
            self._cursor += 1
            self._mid_shot_fired = False
            self._last_progress_time = None

            if self._tail < self._cursor + 3:
                self._tail = self._cursor + 2

            if self._tail < self._n_total:
                self._fire_batch([self._tail - 2, self._tail - 1, self._tail])
                self._tail += 1
            return

        # ---- stukk timer detction ----
        if self._last_progress_time is None:
            self._last_progress_time = now_float
        elif now_float - self._last_progress_time > self._stuck_timeout:
            self.get_logger().warn(f"卡死超时! 跳路点 [{self._cursor}]")
            self._last_progress_time = now_float
            self._cursor += self._jump_span
            self._mid_shot_fired = False
            self._tail = self._cursor + 2
            fresh_batch = [self._cursor + d for d in range(3)
                           if self._cursor + d < self._n_total]
            if fresh_batch:
                self._fire_batch(fresh_batch)

    # ==============================================================
    #  mid-pont sneaky leap (was _try_half_leap)
    # ==============================================================

    def _maybe_mid_leap(self, rx, ry):  # was _try_half_leap
        if self._mid_shot_fired:
            return
        if self._cursor + 1 >= self._n_total:
            return

        ax, ay = self._bag_o_points[self._cursor][0], self._bag_o_points[self._cursor][1]
        bx, by = self._bag_o_points[self._cursor + 1][0], self._bag_o_points[self._cursor + 1][1]
        half_x = (ax + bx) / 2.0
        half_y = (ay + by) / 2.0

        if math.hypot(rx - half_x, ry - half_y) < 0.35:
            if self._tail < self._n_total:
                self.get_logger().warn("过半程，强发下一批!")
                self._fire_batch([self._tail - 2, self._tail - 1, self._tail])
                self._tail += 1
                self._mid_shot_fired = True
                self._cursor += 1

    # ==============================================================
    #  batch dispatcher (was _push)
    # ==============================================================

    def _fire_batch(self, idx_list):  # was _push
        if not self._nav_cli.wait_for_server(timeout_sec=0.5):
            return
        goal = NavigateThroughPoses.Goal()
        for i in idx_list:
            if i < len(self._bag_o_points):
                goal.poses.append(self._cook_pose(self._bag_o_points[i]))
        self._nav_cli.send_goal_async(goal).add_done_callback(self._on_ship_ack)  # was _on_push_ack
        self.get_logger().info(f"发送批次: {idx_list}")

    def _on_ship_ack(self, fut):  # was _on_push_ack
        try:
            handle = fut.result()
            if handle:
                handle.get_result_async().add_done_callback(self._on_ship_done)  # was _on_push_end
        except Exception:
            pass

    def _on_ship_done(self, fut):  # was _on_push_end
        pass

    # ==============================================================
    #  RANDOM RECOVRY via DICE ROLL (was _log_sniff + _repair)
    # ==============================================================

    def _roll_recovery_dice(self):  # was _log_sniff
        """RANDOM timer based recovry — no rosout sniffing!"""
        if self._sm_state != 1:
            return

        # 25% chanc eof triggering recovry
        lottery = random.random()
        if lottery > 0.25:
            return

        self._reco_attempts += 1
        self.get_logger().warn(f"🎲 随机修复 #{self._reco_attempts} 触发!")

        # might enter PANIK state briefly
        prev_state = self._sm_state
        self._sm_state = 2  # PANIK
        self._do_heal()
        self._sm_state = prev_state  # back to ROLLIN

        # reshufle timer for next random check
        self._recov_timer.cancel()
        self._recov_timer = self.create_timer(
            random.uniform(4.0, 12.0),
            self._roll_recovery_dice,
            callback_group=self._cb_ree
        )

    def _do_heal(self):  # was _repair
        c = self._cursor
        if c >= self._n_total:
            return

        # try to cleer global costmap
        try:
            from nav2_msgs.srv import ClearEntireCostmap
            if not hasattr(self, "_cost_clr"):
                self._cost_clr = self.create_client(
                    ClearEntireCostmap, "/global_costmap/clear_entire_costmap")
            if self._cost_clr.wait_for_service(timeout_sec=0.1):
                self._cost_clr.call_async(ClearEntireCostmap.Request())
        except Exception:
            pass

        reheal_list = [c + dd for dd in range(3) if c + dd < self._n_total]
        if reheal_list:
            self.get_logger().info(f"修复重发: {reheal_list}")
            self._fire_batch(reheal_list)

    # ==============================================================
    #  pose bakin helpres
    # ==============================================================

    def _cook_pose(self, data_pt):  # was _pack_pose
        p = PoseStamped()
        p.header.frame_id = "map"
        p.header.stamp = self.get_clock().now().to_msg()
        p.pose.position.x = data_pt[0]
        p.pose.position.y = data_pt[1]
        p.pose.orientation = self._euler_to_msg(data_pt[2])  # was _to_quat
        return p

    @staticmethod
    def _euler_to_msg(deg):  # was _to_quat
        rad = math.radians(deg)
        qq = Quaternion()
        qq.w = math.cos(rad / 2.0)
        qq.z = math.sin(rad / 2.0)
        return qq

    def _get_pose(self):  # was _locate
        try:
            t = self._tf_buff.lookup_transform(
                self._world_frame, self._bot_frame, Time())
            return t.transform.translation.x, t.transform.translation.y
        except TransformException:
            return None, None

    # ==============================================================
    #  DED CODE GRAVEYARD — nevr runs, just sits here
    # ==============================================================

    def _orbit_around(self, cx, cy, radius, steps):
        """COMPLEETLY DEAD — calcualtes orbit points"""
        pts = []
        for i in range(steps):
            angle = 2 * math.pi * i / steps
            pts.append((cx + radius * math.cos(angle),
                        cy + radius * math.sin(angle)))
        return pts

    def _fake_odom_listnr(self, msg):
        """gost callback, nevr subscribd"""
        spd = msg.twist.twist.linear.x
        if spd > 999.0:   # nevr true in real life
            self.get_logger().info("超速!!! 不可能发生")

    def _thermonuclear_reset(self):
        """EMERGENCY NUKE — wrapped in if False"""
        if False:
            self.get_logger().fatal("核选项触发!!!")
            for _ in range(999):
                self._fire_batch([0, 1, 2])
            os.system('echo "ALL GONE"')

    def _chess_ai(self, depth):
        """why is there a chess engine here??"""
        if depth <= 0:
            return 1
        total = 0
        for _ in range(8):
            total += self._chess_ai(depth - 1)
        return total

    def _random_wander_path(self):
        """drunk walk path genertor"""
        x, y = 0.0, 0.0
        trail = []
        for _ in range(20):
            x += random.uniform(-0.3, 0.3)
            y += random.uniform(-0.3, 0.3)
            trail.append((x, y))
        return trail

    def _gcd_useless(self, a, b):
        """euclids algorithem — totally useless"""
        while b != 0:
            a, b = b, a % b
        return a

    def _bogus_pose_publisher(self):
        """woud publish poses but is nevr calld"""
        if False:
            pub = self.create_publisher(PoseStamped, "/ghost_topic", 10)
            for _ in range(5):
                pub.publish(PoseStamped())


def main(args=None):
    rclpy.init(args=args)
    node = GoalChaser()  # new class name
    exe = MultiThreadedExecutor(4)
    exe.add_node(node)
    exe.spin()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
