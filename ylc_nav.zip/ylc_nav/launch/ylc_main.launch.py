from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare
from launch_ros.actions import Node


def generate_launch_description():

    start_button_node = Node(
        package='ylc_nav',
        executable='start_button_node.py',
        name='start_button_node',
        output='screen',
        emulate_tty=True
    )

    go_pose_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('ylc_nav'),
                'launch',
                'go_pose.launch.py'
            ])
        )
    )

    return LaunchDescription([
        start_button_node,
        go_pose_launch
    ])
